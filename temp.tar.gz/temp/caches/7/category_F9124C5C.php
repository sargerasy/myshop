<?php exit;?>a:3:{s:8:"template";a:11:{i:0;s:53:"F:/xamp/xampp/htdocs/shop/themes/default/category.dwt";i:1;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_header.lbi";i:2;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/ur_here.lbi";i:3;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/cart.lbi";i:4;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/category_tree.lbi";i:5;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/history.lbi";i:6;s:67:"F:/xamp/xampp/htdocs/shop/themes/default/library/recommend_best.lbi";i:7;s:63:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_list.lbi";i:8;s:58:"F:/xamp/xampp/htdocs/shop/themes/default/library/pages.lbi";i:9;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/help.lbi";i:10;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_footer.lbi";}s:7:"expires";i:1305605906;s:8:"maketime";i:1305602306;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.2" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<title>手机配件_ECSHOP演示站 - Powered by ECShop</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/default/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/global.js"></script><script type="text/javascript" src="js/compare.js"></script></head>
<body>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div class="block clearfix">
 <div class="f_l"><a href="index.php" name="top"><img src="themes/default/images/logo.gif" /></a></div>
 <div class="f_r log">
   <ul>
   <li class="userInfo">
   <script type="text/javascript" src="js/transport.js"></script><script type="text/javascript" src="js/utils.js"></script>   <font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
   </li>
      <li id="topNav" class="clearfix">
    			            <a href="flow.php" >查看购物车</a>
                         |
            			    			            <a href="pick_out.php" >选购中心</a>
                         |
            			    			            <a href="tag_cloud.php" >标签云</a>
                         |
            			    						    			            <a href="quotation.php" >报价单</a>
            			        <div class="topNavR"></div>
   </li>
      </ul>
 </div>
</div>
<div  class="blank"></div>
<div id="mainNav" class="clearfix">
  <a href="index.php">首页<span></span></a>
    <a href="category.php?id=3"  >GSM手机<span></span></a>
   <a href="category.php?id=5"  >双模手机<span></span></a>
   <a href="category.php?id=6"   class="cur">手机配件<span></span></a>
   <a href="group_buy.php"  >团购商品<span></span></a>
   <a href="activity.php"  >优惠活动<span></span></a>
   <a href="snatch.php"  >夺宝奇兵<span></span></a>
   <a href="auction.php"  >拍卖活动<span></span></a>
   <a href="exchange.php"  >积分商城<span></span></a>
   <a href="message.php"  >留言板<span></span></a>
   <a href="http://bbs.ecshop.com/" target="_blank"  >EC论坛<span></span></a>
 </div>
<div id="search"  class="clearfix">
  <div class="keys f_l">
   <script type="text/javascript">
    
    <!--
    function checkSearchForm()
    {
        if(document.getElementById('keyword').value)
        {
            return true;
        }
        else
        {
            alert("请输入搜索关键词！");
            return false;
        }
    }
    -->
    
    </script>
      </div>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="f_r"  style="_position:relative; top:5px;">
   <select name="category" id="category" class="B_input">
      <option value="0">所有分类</option>
      <option value="12" >充值卡</option><option value="15" >&nbsp;&nbsp;&nbsp;&nbsp;联通手机充值卡</option><option value="13" >&nbsp;&nbsp;&nbsp;&nbsp;小灵通/固话充值卡</option><option value="14" >&nbsp;&nbsp;&nbsp;&nbsp;移动手机充值卡</option><option value="6" >手机配件</option><option value="8" >&nbsp;&nbsp;&nbsp;&nbsp;耳机</option><option value="9" >&nbsp;&nbsp;&nbsp;&nbsp;电池</option><option value="11" >&nbsp;&nbsp;&nbsp;&nbsp;读卡器和内存卡</option><option value="7" >&nbsp;&nbsp;&nbsp;&nbsp;充电器</option><option value="1" >手机类型</option><option value="5" >&nbsp;&nbsp;&nbsp;&nbsp;双模手机</option><option value="2" >&nbsp;&nbsp;&nbsp;&nbsp;CDMA手机</option><option value="3" >&nbsp;&nbsp;&nbsp;&nbsp;GSM手机</option><option value="4" >&nbsp;&nbsp;&nbsp;&nbsp;3G手机</option>    </select>
   <input name="keywords" type="text" id="keyword" value="" class="B_input" style="width:110px;"/>
   <input name="imageField" type="submit" value="" class="go" style="cursor:pointer;" />
   <a href="search.php?act=advanced_search">高级搜索</a>
   </form>
</div>
<div class="block box">
 <div id="ur_here">
  当前位置: <a href=".">首页</a> <code>&gt;</code> <a href="category.php?id=6">手机配件</a> </div>
</div>
<div class="blank"></div>
<div class="block clearfix">
  
  <div class="AreaL">
    
<div class="cart" id="ECS_CARTINFO">
 554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca</div>
<div class="blank5"></div>
<div class="box">
 <div class="box_1">
  <div id="category_tree">
         <dl>
     <dt><a href="category.php?id=1">手机类型</a></dt>
          <dd><a href="category.php?id=2">CDMA手机</a></dd>
                 <dd><a href="category.php?id=3">GSM手机</a></dd>
                 <dd><a href="category.php?id=4">3G手机</a></dd>
                 <dd><a href="category.php?id=5">双模手机</a></dd>
                   
       </dl>
         <dl>
     <dt><a href="category.php?id=6">手机配件</a></dt>
          <dd><a href="category.php?id=7">充电器</a></dd>
                 <dd><a href="category.php?id=8">耳机</a></dd>
              <dd>&nbsp;&nbsp;<a href="category.php?id=16">123</a></dd>
                 <dd><a href="category.php?id=9">电池</a></dd>
                 <dd><a href="category.php?id=11">读卡器和内存卡</a></dd>
                   
       </dl>
         <dl>
     <dt><a href="category.php?id=12">充值卡</a></dt>
          <dd><a href="category.php?id=13">小灵通/固话充值卡</a></dd>
                 <dd><a href="category.php?id=14">移动手机充值卡</a></dd>
                 <dd><a href="category.php?id=15">联通手机充值卡</a></dd>
                   
       </dl>
     
  </div>
 </div>
</div>
<div class="blank5"></div>
 <div class="box" id='history_div'>
 <div class="box_1">
  <h3><span>浏览历史</span></h3>
  <div class="boxCenterList clearfix" id='history_list'>
    554fcae493e564ee0dc75bdf2ebf94cahistory|a:1:{s:4:"name";s:7:"history";}554fcae493e564ee0dc75bdf2ebf94ca  </div>
 </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
if (document.getElementById('history_list').innerHTML.replace(/\s/g,'').length<1)
{
    document.getElementById('history_div').style.display='none';
}
else
{
    document.getElementById('history_div').style.display='block';
}
function clear_history()
{
Ajax.call('user.php', 'act=clear_history',clear_history_Response, 'GET', 'TEXT',1,1);
}
function clear_history_Response(res)
{
document.getElementById('history_list').innerHTML = '您已清空最近浏览过的商品';
}
</script>
    
  </div>
  
  
  <div class="AreaR">
	 
	  	  <div class="box">
		 <div class="box_1">
			<h3><span>商品筛选</span></h3>
						<div class="screeBox">
			  <strong>品牌：</strong>
														<span>全部</span>
																			<a href="category.php?id=6&amp;brand=1&amp;price_min=0&amp;price_max=0">诺基亚</a>&nbsp;
																			<a href="category.php?id=6&amp;brand=7&amp;price_min=0&amp;price_max=0">索爱</a>&nbsp;
												</div>
											 </div>
		</div>
		<div class="blank5"></div>
	  	 
   
<div class="box">
<div class="box_2 centerPadd">
  <div class="itemTit" id="itemBest">
        </div>
  <div id="show_best_area" class="clearfix goodsBox">
      <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=5"><img src="images/200905/thumb_img/5_thumb_G_1241422518886.jpg" alt="索爱原装M2卡读卡器" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=5" title="索爱原装M2卡读卡器">索爱原装M2卡...</a></p>
           <font class="f1">
                     ￥20元                     </font>
        </div>
    <div class="more"><a href="search.php?intro=best"><img src="themes/default/images/more.gif" /></a></div>
    </div>
</div>
</div>
<div class="blank5"></div>
    <div class="box">
 <div class="box_1">
  <h3>
  <span>商品列表</span><a name='goods_list'></a>
  <form method="GET" class="sort" name="listform">
  显示方式：
  <a href="javascript:;" onClick="javascript:display_mode('list')"><img src="themes/default/images/display_mode_list.gif" alt=""></a>
  <a href="javascript:;" onClick="javascript:display_mode('grid')"><img src="themes/default/images/display_mode_grid_act.gif" alt=""></a>
  <a href="javascript:;" onClick="javascript:display_mode('text')"><img src="themes/default/images/display_mode_text.gif" alt=""></a>&nbsp;&nbsp;
  
  <a href="category.php?category=6&display=grid&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=goods_id&order=ASC#goods_list"><img src="themes/default/images/goods_id_DESC.gif" alt="按上架时间排序"></a>
  <a href="category.php?category=6&display=grid&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=shop_price&order=ASC#goods_list"><img src="themes/default/images/shop_price_default.gif" alt="按价格排序"></a>
  <a href="category.php?category=6&display=grid&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=last_update&order=DESC#goods_list"><img src="themes/default/images/last_update_default.gif" alt="按更新时间排序"></a>
  <input type="hidden" name="category" value="6" />
  <input type="hidden" name="display" value="grid" id="display" />
  <input type="hidden" name="brand" value="0" />
  <input type="hidden" name="price_min" value="0" />
  <input type="hidden" name="price_max" value="0" />
  <input type="hidden" name="filter_attr" value="0" />
  <input type="hidden" name="page" value="1" />
  <input type="hidden" name="sort" value="goods_id" />
  <input type="hidden" name="order" value="DESC" />
  </form>
  </h3>
      <form name="compareForm" action="compare.php" method="post" onSubmit="return compareGoods(this);">
            <div class="centerPadd">
    <div class="clearfix goodsBox" style="border:none;">
             <div class="goodsItem">
           <a href="goods.php?id=7"><img src="images/200905/thumb_img/7_thumb_G_1241422785492.jpg" alt="诺基亚N85原..." class="goodsimg" /></a><br />
           <p><a href="goods.php?id=7" title="诺基亚N85原装立体声耳机HS-82">诺基亚N85原...</a></p>
                       市场价<font class="market_s">￥120元</font><br />
                                    本店价<font class="shop_s">￥100元</font><br />
                       <a href="javascript:collect(7);" class="f6">收藏</a> |
           <a href="javascript:addToCart(7)" class="f6">购买</a> |
           <a href="javascript:;" id="compareLink" onClick="Compare.add(7,'诺基亚N85原...','2')" class="f6">比较</a>
        </div>
                 <div class="goodsItem">
           <a href="goods.php?id=5"><img src="images/200905/thumb_img/5_thumb_G_1241422518886.jpg" alt="索爱原装M2卡..." class="goodsimg" /></a><br />
           <p><a href="goods.php?id=5" title="索爱原装M2卡读卡器">索爱原装M2卡...</a></p>
                       市场价<font class="market_s">￥24元</font><br />
                                    本店价<font class="shop_s">￥20元</font><br />
                       <a href="javascript:collect(5);" class="f6">收藏</a> |
           <a href="javascript:addToCart(5)" class="f6">购买</a> |
           <a href="javascript:;" id="compareLink" onClick="Compare.add(5,'索爱原装M2卡...','2')" class="f6">比较</a>
        </div>
                 <div class="goodsItem">
           <a href="goods.php?id=3"><img src="images/200905/thumb_img/3_thumb_G_1241422082679.jpg" alt="诺基亚原装58..." class="goodsimg" /></a><br />
           <p><a href="goods.php?id=3" title="诺基亚原装5800耳机">诺基亚原装58...</a></p>
                       市场价<font class="market_s">￥82元</font><br />
                                    本店价<font class="shop_s">￥68元</font><br />
                       <a href="javascript:collect(3);" class="f6">收藏</a> |
           <a href="javascript:addToCart(3)" class="f6">购买</a> |
           <a href="javascript:;" id="compareLink" onClick="Compare.add(3,'诺基亚原装58...','6')" class="f6">比较</a>
        </div>
                    </div>
    </div>
        </form>
  
 </div>
</div>
<div class="blank5"></div>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script>
<script type="text/javascript">
window.onload = function()
{
  Compare.init();
  fixpng();
}
var button_compare = '';
var exist = "您已经选择了%s";
var count_limit = "最多只能选择4个商品进行对比";
var goods_type_different = "\"%s\"和已选择商品类型不同无法进行对比";
var compare_no_goods = "您没有选定任何需要比较的商品或者比较的商品数少于 2 个。";
var btn_buy = "购买";
var is_cancel = "取消";
var select_spe = "请选择商品属性";
</script>  
<form name="selectPageForm" action="/shop/category.php" method="get">
 <div id="pager" class="pagebar">
  <span class="f_l f6" style="margin-right:10px;">总计 <b>3</b>  个记录</span>
      
      </div>
</form>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script>
  </div>  
  
</div>
<div class="blank5"></div>
<div class="block">
  <div class="box">
   <div class="helpTitBg clearfix">
    <dl>
  <dt><a href='article_cat.php?id=5' title="新手上路 ">新手上路 </a></dt>
    <dd><a href="article.php?id=9" title="售后流程">售后流程</a></dd>
    <dd><a href="article.php?id=10" title="购物流程">购物流程</a></dd>
    <dd><a href="article.php?id=11" title="订购方式">订购方式</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=6' title="手机常识 ">手机常识 </a></dt>
    <dd><a href="article.php?id=12" title="如何分辨原装电池">如何分辨原装电池</a></dd>
    <dd><a href="article.php?id=13" title="如何分辨水货手机 ">如何分辨水货手机</a></dd>
    <dd><a href="article.php?id=14" title="如何享受全国联保">如何享受全国联保</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=7' title="配送与支付 ">配送与支付 </a></dt>
    <dd><a href="article.php?id=15" title="货到付款区域">货到付款区域</a></dd>
    <dd><a href="article.php?id=16" title="配送支付智能查询 ">配送支付智能查询</a></dd>
    <dd><a href="article.php?id=17" title="支付方式说明">支付方式说明</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=10' title="会员中心">会员中心</a></dt>
    <dd><a href="article.php?id=18" title="资金管理">资金管理</a></dd>
    <dd><a href="article.php?id=19" title="我的收藏">我的收藏</a></dd>
    <dd><a href="article.php?id=20" title="我的订单">我的订单</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=8' title="服务保证 ">服务保证 </a></dt>
    <dd><a href="article.php?id=21" title="退换货原则">退换货原则</a></dd>
    <dd><a href="article.php?id=22" title="售后服务保证 ">售后服务保证</a></dd>
    <dd><a href="article.php?id=23" title="产品质量保证 ">产品质量保证</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=9' title="联系我们 ">联系我们 </a></dt>
    <dd><a href="article.php?id=24" title="网站故障报告">网站故障报告</a></dd>
    <dd><a href="article.php?id=25" title="选机咨询 ">选机咨询</a></dd>
    <dd><a href="article.php?id=26" title="投诉与建议 ">投诉与建议</a></dd>
  </dl>
   </div>
  </div>  
</div>
<div class="blank"></div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="bNavList clearfix">
   <div class="f_l">
              <a href="article.php?id=1" >免责条款</a>
                   -
                      <a href="article.php?id=2" >隐私保护</a>
                   -
                      <a href="article.php?id=3" >咨询热点</a>
                   -
                      <a href="article.php?id=4" >联系我们</a>
                   -
                      <a href="article.php?id=5" >公司简介</a>
                   -
                      <a href="wholesale.php" >批发方案</a>
                   -
                      <a href="myship.php" >配送方式</a>
                   -
                      <a href="user.php?act=register&type=agent" >业务经理注册</a>
                   -
                      <a href="user.php?act=register&type=distributor" >经销商注册</a>
                   </div>
   <div class="f_r">
   <a href="#top"><img src="themes/default/images/bnt_top.gif" /></a> <a href="index.php"><img src="themes/default/images/bnt_home.gif" /></a>
   </div>
  </div>
 </div>
</div>
<div class="blank"></div>
<div id="footer">
 <div class="text">
 &copy; 2005-2011 ECSHOP 版权所有，并保留所有权利。<br />
                                                                                     <br />
    554fcae493e564ee0dc75bdf2ebf94caquery_info|a:1:{s:4:"name";s:10:"query_info";}554fcae493e564ee0dc75bdf2ebf94ca<br />
  <a href="http://www.ecshop.com" target="_blank" style=" font-family:Verdana; font-size:11px;">Powered&nbsp;by&nbsp;<strong><span style="color: #3366FF">ECShop</span>&nbsp;<span style="color: #FF9966">v2.7.2</span></strong></a>&nbsp;<br />
        <div align="left"  id="rss"><a href="feed.php?cat=6"><img src="themes/default/images/xml_rss2.gif" alt="rss" /></a></div>
 </div>
</div>
</body>
</html>
