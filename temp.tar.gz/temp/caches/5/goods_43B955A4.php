<?php exit;?>a:3:{s:8:"template";a:17:{i:0;s:50:"F:/xamp/xampp/htdocs/shop/themes/default/goods.dwt";i:1;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_header.lbi";i:2;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/ur_here.lbi";i:3;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/cart.lbi";i:4;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/category_tree.lbi";i:5;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_related.lbi";i:6;s:67:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_fittings.lbi";i:7;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_article.lbi";i:8;s:69:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_attrlinked.lbi";i:9;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/history.lbi";i:10;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_gallery.lbi";i:11;s:63:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_tags.lbi";i:12;s:65:"F:/xamp/xampp/htdocs/shop/themes/default/library/bought_goods.lbi";i:13;s:70:"F:/xamp/xampp/htdocs/shop/themes/default/library/bought_note_guide.lbi";i:14;s:61:"F:/xamp/xampp/htdocs/shop/themes/default/library/comments.lbi";i:15;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/help.lbi";i:16;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_footer.lbi";}s:7:"expires";i:1305621817;s:8:"maketime";i:1305618217;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.2" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="旅行充电器 图形菜单 Wap 上网 红外接口 移动 MSN 支持 2008年06月 灰色" />
<meta name="Description" content="" />
<title>P806_GSM手机_手机类型_ECSHOP演示站 - Powered by ECShop</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/default/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript">
function $id(element) {
  return document.getElementById(element);
}
//切屏--是按钮，_v是内容平台，_h是内容库
function reg(str){
  var bt=$id(str+"_b").getElementsByTagName("h2");
  for(var i=0;i<bt.length;i++){
    bt[i].subj=str;
    bt[i].pai=i;
    bt[i].style.cursor="pointer";
    bt[i].onclick=function(){
      $id(this.subj+"_v").innerHTML=$id(this.subj+"_h").getElementsByTagName("blockquote")[this.pai].innerHTML;
      for(var j=0;j<$id(this.subj+"_b").getElementsByTagName("h2").length;j++){
        var _bt=$id(this.subj+"_b").getElementsByTagName("h2")[j];
        var ison=j==this.pai;
        _bt.className=(ison?"":"h2bg");
      }
    }
  }
  $id(str+"_h").className="none";
  $id(str+"_v").innerHTML=$id(str+"_h").getElementsByTagName("blockquote")[0].innerHTML;
}
</script>
</head>
<body>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div class="block clearfix">
 <div class="f_l"><a href="index.php" name="top"><img src="themes/default/images/logo.gif" /></a></div>
 <div class="f_r log">
   <ul>
   <li class="userInfo">
   <script type="text/javascript" src="js/transport.js"></script><script type="text/javascript" src="js/utils.js"></script>   <font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
   </li>
      <li id="topNav" class="clearfix">
    			            <a href="flow.php" >查看购物车</a>
                         |
            			    			            <a href="pick_out.php" >选购中心</a>
                         |
            			    			            <a href="tag_cloud.php" >标签云</a>
                         |
            			    						    			            <a href="quotation.php" >报价单</a>
            			        <div class="topNavR"></div>
   </li>
      </ul>
 </div>
</div>
<div  class="blank"></div>
<div id="mainNav" class="clearfix">
  <a href="index.php">首页<span></span></a>
    <a href="category.php?id=3"   class="cur">GSM手机<span></span></a>
   <a href="category.php?id=5"  >双模手机<span></span></a>
   <a href="category.php?id=6"  >手机配件<span></span></a>
   <a href="group_buy.php"  >团购商品<span></span></a>
   <a href="activity.php"  >优惠活动<span></span></a>
   <a href="snatch.php"  >夺宝奇兵<span></span></a>
   <a href="auction.php"  >拍卖活动<span></span></a>
   <a href="exchange.php"  >积分商城<span></span></a>
   <a href="message.php"  >留言板<span></span></a>
   <a href="http://bbs.ecshop.com/" target="_blank"  >EC论坛<span></span></a>
 </div>
<div id="search"  class="clearfix">
  <div class="keys f_l">
   <script type="text/javascript">
    
    <!--
    function checkSearchForm()
    {
        if(document.getElementById('keyword').value)
        {
            return true;
        }
        else
        {
            alert("请输入搜索关键词！");
            return false;
        }
    }
    -->
    
    </script>
      </div>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="f_r"  style="_position:relative; top:5px;">
   <select name="category" id="category" class="B_input">
      <option value="0">所有分类</option>
      <option value="12" >充值卡</option><option value="15" >&nbsp;&nbsp;&nbsp;&nbsp;联通手机充值卡</option><option value="13" >&nbsp;&nbsp;&nbsp;&nbsp;小灵通/固话充值卡</option><option value="14" >&nbsp;&nbsp;&nbsp;&nbsp;移动手机充值卡</option><option value="6" >手机配件</option><option value="8" >&nbsp;&nbsp;&nbsp;&nbsp;耳机</option><option value="9" >&nbsp;&nbsp;&nbsp;&nbsp;电池</option><option value="11" >&nbsp;&nbsp;&nbsp;&nbsp;读卡器和内存卡</option><option value="7" >&nbsp;&nbsp;&nbsp;&nbsp;充电器</option><option value="1" >手机类型</option><option value="5" >&nbsp;&nbsp;&nbsp;&nbsp;双模手机</option><option value="2" >&nbsp;&nbsp;&nbsp;&nbsp;CDMA手机</option><option value="3" >&nbsp;&nbsp;&nbsp;&nbsp;GSM手机</option><option value="4" >&nbsp;&nbsp;&nbsp;&nbsp;3G手机</option>    </select>
   <input name="keywords" type="text" id="keyword" value="" class="B_input" style="width:110px;"/>
   <input name="imageField" type="submit" value="" class="go" style="cursor:pointer;" />
   <a href="search.php?act=advanced_search">高级搜索</a>
   </form>
</div>
<div class="block box">
 <div id="ur_here">
  当前位置: <a href=".">首页</a> <code>&gt;</code> <a href="category.php?id=1">手机类型</a> <code>&gt;</code> <a href="category.php?id=3">GSM手机</a> <code>&gt;</code> P806 </div>
</div>
<div class="blank"></div>
<div class="block clearfix">
  
  <div class="AreaL">
    
<div class="cart" id="ECS_CARTINFO">
 554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca</div>
<div class="blank5"></div>
<div class="box">
 <div class="box_1">
  <div id="category_tree">
         <dl>
     <dt><a href="category.php?id=2">CDMA手机</a></dt>
            
       </dl>
         <dl>
     <dt><a href="category.php?id=3">GSM手机</a></dt>
            
       </dl>
         <dl>
     <dt><a href="category.php?id=4">3G手机</a></dt>
            
       </dl>
         <dl>
     <dt><a href="category.php?id=5">双模手机</a></dt>
            
       </dl>
     
  </div>
 </div>
</div>
<div class="blank5"></div>
    
    <div class="box" id='history_div'>
 <div class="box_1">
  <h3><span>浏览历史</span></h3>
  <div class="boxCenterList clearfix" id='history_list'>
    554fcae493e564ee0dc75bdf2ebf94cahistory|a:1:{s:4:"name";s:7:"history";}554fcae493e564ee0dc75bdf2ebf94ca  </div>
 </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
if (document.getElementById('history_list').innerHTML.replace(/\s/g,'').length<1)
{
    document.getElementById('history_div').style.display='none';
}
else
{
    document.getElementById('history_div').style.display='block';
}
function clear_history()
{
Ajax.call('user.php', 'act=clear_history',clear_history_Response, 'GET', 'TEXT',1,1);
}
function clear_history_Response(res)
{
document.getElementById('history_list').innerHTML = '您已清空最近浏览过的商品';
}
</script>  </div>
  
  
  <div class="AreaR">
   
   <div id="goodsInfo" class="clearfix">
     
     <div class="imgInfo">
          <a href="javascript:;" onclick="window.open('gallery.php?id=24'); return false;">
      <img src="images/200905/goods_img/24_G_1241971981284.jpg" alt="P806"/>
     </a>
              <div class="blank5"></div>
     
      <div class="clearfix">
      <span onmouseover="moveLeft()" onmousedown="clickLeft()" onmouseup="moveLeft()" onmouseout="scrollStop()"></span>
      <div class="gallery">
        <div id="demo">
          <div id="demo1" style="float:left">
            <ul>
                         <li><a href="gallery.php?id=24&amp;img=30" target="_blank"><img src="images/200905/thumb_img/24_thumb_P_1241971981834.jpg" alt="P806" class="B_blue" /></a>
            </li>
                        </ul>
          </div>
          <div id="demo2" style="display:inline; overflow:visible;"></div>
        </div>
      </div>
      <span onmouseover="moveRight()" onmousedown="clickRight()" onmouseup="moveRight()" onmouseout="scrollStop()" class="spanR"></span>
      <script>
      function $gg(id){  
        return (document.getElementById) ? document.getElementById(id): document.all[id]
      }
      
      var boxwidth=53;//跟图片的实际尺寸相符
      
      var box=$gg("demo");
      var obox=$gg("demo1");
      var dulbox=$gg("demo2");
      obox.style.width=obox.getElementsByTagName("li").length*boxwidth+'px';
      dulbox.style.width=obox.getElementsByTagName("li").length*boxwidth+'px';
      box.style.width=obox.getElementsByTagName("li").length*boxwidth*3+'px';
      var canroll = false;
      if (obox.getElementsByTagName("li").length >= 4) {
        canroll = true;
        dulbox.innerHTML=obox.innerHTML;
      }
      var step=5;temp=1;speed=50;
      var awidth=obox.offsetWidth;
      var mData=0;
      var isStop = 1;
      var dir = 1;
      
      function s(){
        if (!canroll) return;
        if (dir) {
      if((awidth+mData)>=0)
      {
      mData=mData-step;
      }
      else
      {
      mData=-step;
      }
      } else {
        if(mData>=0)
        {
        mData=-awidth;
        }
        else
        {
        mData+=step;
        }
      }
      
      obox.style.marginLeft=mData+"px";
      
      if (isStop) return;
      
      setTimeout(s,speed)
      }
      
      
      function moveLeft() {
          var wasStop = isStop;
          dir = 1;
          speed = 50;
          isStop=0;
          if (wasStop) {
            setTimeout(s,speed);
          }
      }
      
      function moveRight() {
          var wasStop = isStop;
          dir = 0;
          speed = 50;
          isStop=0;
          if (wasStop) {
            setTimeout(s,speed);
          }
      }
      
      function scrollStop() {
        isStop=1;
      }
      
      function clickLeft() {
          var wasStop = isStop;
          dir = 1;
          speed = 25;
          isStop=0;
          if (wasStop) {
            setTimeout(s,speed);
          }
      }
      
      function clickRight() {
          var wasStop = isStop;
          dir = 0;
          speed = 25;
          isStop=0;
          if (wasStop) {
            setTimeout(s,speed);
          }
      }
      </script> 
     </div>
		       
         <div class="blank5"></div>
         
     </div>
     
     <div class="textInfo">
     <form action="javascript:addToCart(24)" method="post" name="ECS_FORMBUY" id="ECS_FORMBUY" >
     <div class="clearfix">
      <p class="f_l">P806</p>
      <p class="f_r">
            <a href="goods.php?id=32"><img alt="prev" src="themes/default/images/up.gif" /></a>
                  <a href="goods.php?id=22"><img alt="next" src="themes/default/images/down.gif" /></a>
            </p>
      </div>
      <ul>
             <li class="padd">
            本商品正在进行            <a href="group_buy.php" title="团购活动" style="font-weight:100; color:#006bcd; text-decoration:none;">[团购活动]</a>
            <a href="group_buy.php?act=view&amp;id=8" title="团购活动 P806的时间为2009-05-15到2011-05-26，赶快来抢吧！" style="font-weight:100; color:#006bcd;">P806</a><br />
            </li>
            <li class="clearfix">
       <dd>
              <strong>商品货号：</strong>ECS000024              </dd>
       <dd class="ddR">
                         <strong>商品库存：</strong>
          100 台                     </dd>
      </li>
      <li class="clearfix">
       <dd>
              <strong>商品品牌：</strong><a href="brand.php?id=9" >联想</a>
              </dd>
       <dd class="ddR">
              <strong>商品重量：</strong>0克              </dd>
      </li>
      <li class="clearfix">
       <dd>
             <strong>上架时间：</strong>2009-05-11             </dd>
       <dd class="ddR">
       
       <strong>商品点击数：</strong>48       </dd>
      </li>
      <li class="clearfix">
       <dd class="ddL">
              <strong>市场价格：</strong><font class="market">￥2400元</font><br />
              
       <strong>本店售价：</strong><font class="shop" id="ECS_SHOPPRICE">￥2000元</font><br />
              <strong>注册用户：</strong><font class="shop" id="ECS_RANKPRICE_1">￥2000元</font><br />
              <strong>vip：</strong><font class="shop" id="ECS_RANKPRICE_2">￥1900元</font><br />
              </dd>
       <dd style="width:48%; padding-left:7px;">
       <strong>用户评价：</strong>
      <img src="themes/default/images/stars5.gif" alt="comment rank 5" />
       </dd>
      </li>
      
            <li class="clearfix">
       <dd>
       <strong>商品总价：</strong><font id="ECS_GOODS_AMOUNT" class="shop"></font>
       </dd>
       <dd class="ddR">
              </dd>
      </li>
            <li class="clearfix">
       <dd>
       <strong>购买数量：</strong>
        <input name="number" type="text" id="number" value="1" size="4" onblur="changePrice()" style="border:1px solid #ccc; "/>
       </dd>
       <dd class="ddR">
              <strong>购买此商品可使用：</strong><font class="f4">2000 积分</font>
              </dd>
      </li>
            
            <li class="padd loop">
      <strong>颜色:</strong><br />
        
                                                                                          <label for="spec_value_167">
                        <input type="radio" name="spec_185" value="167" id="spec_value_167" checked onclick="changePrice()" />
                        灰色 [ ￥0.00元] </label><br />
                                                <input type="hidden" name="spec_list" value="0" />
                                                  </li>
            <li class="padd loop">
      <strong>配件:</strong><br />
        
                                                                <label for="spec_value_168">
                      <input type="checkbox" name="spec_210" value="168" id="spec_value_168" onclick="changePrice()" />
                      数据线 [加 ￥20.00元] </label><br />
                                            <input type="hidden" name="spec_list" value="0" />
                          </li>
            
      <li class="padd">
      <a href="javascript:addToCart(24)"><img src="themes/default/images/bnt_cat.gif" /></a>
      <a href="javascript:collect(24)"><img src="themes/default/images/bnt_colles.gif" /></a>
            <a href="user.php?act=affiliate&goodsid=24"><img src='themes/default/images/bnt_recommend.gif'></a>
            </li>
      </ul>
      </form>
     </div>
   </div>
   <div class="blank"></div>
   
   
     <div class="box">
     <div class="box_1">
      <h3 style="padding:0 5px;">
        <div id="com_b" class="history clearfix">
        <h2>商品描述：</h2>
        <h2 class="h2bg">商品属性</h2>
                </div>
      </h3>
      <div id="com_v" class="boxCenterList RelaArticle"></div>
      <div id="com_h">
       <blockquote>
        <div>
<div>
<div><font size="4">规格参数</font></div>
<p><font size="4"><span>上市时间：</span><span>2008年06月</span></font></p>
<p><font size="4"><span>网络频率：</span><span>GSM/GPRS；900/1800MHz</span></font></p>
<p><font size="4"><span>重　量　：</span><span>未知</span></font></p>
<p><font size="4"><span>尺寸/体积：</span><span>未知</span></font></p>
<p><font size="4"><span>可选颜色：</span><span>银色</span></font></p>
<p><font size="4"><span>屏幕参数：</span><span>26万色TFT彩色屏幕；</span></font></p>
<p><font size="4"><span>WAP上网：</span><span>支持飞笺</span></font></p>
<p><font size="4"><span>基本配置:<em><strong><font size="5" color="#ff00ff">二电(1760毫安) 一充 数据线 耳机 手写笔 512M内存卡</font></strong></em></span></font></p>
<p>&nbsp;</p>
</div>
</div>
<div><font size="4">基本功能</font></div>
<p><font size="4"><span>『时钟』</span><span>『内置振动』</span><span>『录音』</span><span>『可选铃声』</span></font></p>
<p><font size="4"><span>『和弦铃声』</span><span>『MP3铃声』</span><span>『来电铃声识别』</span><span>『来电图片识别』</span></font></p>
<p><font size="4"><span>『情景模式』</span><span>『待机图片』</span><span>『图形菜单』</span><span>『触摸屏』</span></font></p>
<p><span><font size="4">『手写输入』</font></span></p>
<div><font size="4">通信功能</font></div>
<p><font size="4"><span>『双卡双待』</span><span>『内置天线』</span><span>『输入法』</span><span>『中文短信』</span></font></p>
<p><font size="4"><span>『短信群发』</span><span>『多媒体短信』</span><span>『话机通讯录』</span><span>『通话记录』</span></font></p>
<p><font size="4"><span>『免提通话』</span><span>『飞行模式』</span></font></p>
<div><font size="4">多媒体娱乐 :支持3GP、MP4文件播放</font></div>
<p><font size="4"><span>『视频播放』</span><span>『MP3播放器』</span></font></p>
<p><font size="4"><span>多媒体卡扩展：</span><span>支持microSD卡扩展&nbsp;</span></font></p>
<p><font size="4"><span>摄像头：</span><span>内置</span></font></p>
<p><font size="4"><span>摄像头像素：</span><span>30万像素</span></font></p>
<p><font size="4"><span>传感器类型：</span><span>CMOS</span></font></p>
<p><font size="4"><span>变焦模式：</span><span>数码变焦</span></font></p>
<p><font size="4"><span>照片分辨率：</span><span>多种照片分辨率选择</span></font></p>
<p><font size="4"><span>拍摄模式：</span><span>多种拍摄模式选择</span></font></p>
<p><font size="4"><span>照片质量：</span><span>多种照片质量选择</span></font></p>
<p><font size="4"><span>视频拍摄：</span><span>有声视频拍摄</span></font></p>
<div><font size="4">数据传输</font></div>
<p><font size="4"><span>『WAP浏览器』</span><span>『数据线接口』</span></font></p>
<div><font size="4">个人助理</font></div>
<p><font size="4"><span>『闹钟』</span><span>『日历』</span><span>『计算器』</span></font></p>       </blockquote>
     <blockquote>
      <table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#dddddd">
                <tr>
          <th colspan="2" bgcolor="#FFFFFF">商品属性</th>
        </tr>
                <tr>
          <td bgcolor="#FFFFFF" align="left" width="30%" class="f1">[上市日期]</td>
          <td bgcolor="#FFFFFF" align="left" width="70%">2008年06月</td>
        </tr>
                <tr>
          <td bgcolor="#FFFFFF" align="left" width="30%" class="f1">[K-JAVA]</td>
          <td bgcolor="#FFFFFF" align="left" width="70%">支持</td>
        </tr>
                <tr>
          <td bgcolor="#FFFFFF" align="left" width="30%" class="f1">[中文输入法]</td>
          <td bgcolor="#FFFFFF" align="left" width="70%">支持</td>
        </tr>
                <tr>
          <td bgcolor="#FFFFFF" align="left" width="30%" class="f1">[中文短消息]</td>
          <td bgcolor="#FFFFFF" align="left" width="70%">SMS</td>
        </tr>
                      </table>
     </blockquote>
     
      </div>
     </div>
    </div>
    <script type="text/javascript">
    <!--
    reg("com");
    //-->
    </script>
  <div class="blank"></div>
  
  
     <div class="box">
     <div class="box_1">
      <h3><span class="text">商品标签</span></h3>
      <div class="boxCenterList clearfix ie6">
       <form name="tagForm" action="javascript:;" onSubmit="return submitTag(this)" id="tagForm">
        <p id="ECS_TAGS" style="margin-bottom:5px;">
                  </p>
        <p>
          <input type="text" name="tag" id="tag" class="inputBg" size="35" />
          <input type="submit" value="添 加" class="bnt_blue" style="border:none;" />
          <input type="hidden" name="goods_id" value="24"  />
        </p>
                <script type="text/javascript">
                //<![CDATA[
                
                /**
                 * 用户添加标记的处理函数
                 */
                function submitTag(frm)
                {
                  try
                  {
                    var tag = frm.elements['tag'].value;
                    var idx = frm.elements['goods_id'].value;
                    if (tag.length > 0 && parseInt(idx) > 0)
                    {
                      Ajax.call('user.php?act=add_tag', "id=" + idx + "&tag=" + tag, submitTagResponse, "POST", "JSON");
                    }
                  }
                  catch (e) {alert(e);}
                  return false;
                }
                function submitTagResponse(result)
                {
                  var div = document.getElementById('ECS_TAGS');
                  if (result.error > 0)
                  {
                    alert(result.message);
                  }
                  else
                  {
                    try
                    {
                      div.innerHTML = '';
                      var tags = result.content;
                      for (i = 0; i < tags.length; i++)
                      {
                        div.innerHTML += '<a href="search.php?keywords='+tags[i].word+'" style="color:#006ace; text-decoration:none; margin-right:5px;">' +tags[i].word + '[' + tags[i].count + ']<\/a>&nbsp;&nbsp; ';
                      }
                    }
                    catch (e) {alert(e);}
                  }
                }
                
                //]]>
                </script>
              </form>
      </div>
     </div>
    </div>
    <div class="blank5"></div>
<div id="ECS_BOUGHT">554fcae493e564ee0dc75bdf2ebf94cabought_notes|a:2:{s:4:"name";s:12:"bought_notes";s:2:"id";i:24;}554fcae493e564ee0dc75bdf2ebf94ca</div><div id="ECS_COMMENT"> 554fcae493e564ee0dc75bdf2ebf94cacomments|a:3:{s:4:"name";s:8:"comments";s:4:"type";i:0;s:2:"id";i:24;}554fcae493e564ee0dc75bdf2ebf94ca</div>
  </div>
  
</div>
<div class="blank5"></div>
<div class="block">
  <div class="box">
   <div class="helpTitBg clearfix">
    <dl>
  <dt><a href='article_cat.php?id=5' title="新手上路 ">新手上路 </a></dt>
    <dd><a href="article.php?id=9" title="售后流程">售后流程</a></dd>
    <dd><a href="article.php?id=10" title="购物流程">购物流程</a></dd>
    <dd><a href="article.php?id=11" title="订购方式">订购方式</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=6' title="手机常识 ">手机常识 </a></dt>
    <dd><a href="article.php?id=12" title="如何分辨原装电池">如何分辨原装电池</a></dd>
    <dd><a href="article.php?id=13" title="如何分辨水货手机 ">如何分辨水货手机</a></dd>
    <dd><a href="article.php?id=14" title="如何享受全国联保">如何享受全国联保</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=7' title="配送与支付 ">配送与支付 </a></dt>
    <dd><a href="article.php?id=15" title="货到付款区域">货到付款区域</a></dd>
    <dd><a href="article.php?id=16" title="配送支付智能查询 ">配送支付智能查询</a></dd>
    <dd><a href="article.php?id=17" title="支付方式说明">支付方式说明</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=10' title="会员中心">会员中心</a></dt>
    <dd><a href="article.php?id=18" title="资金管理">资金管理</a></dd>
    <dd><a href="article.php?id=19" title="我的收藏">我的收藏</a></dd>
    <dd><a href="article.php?id=20" title="我的订单">我的订单</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=8' title="服务保证 ">服务保证 </a></dt>
    <dd><a href="article.php?id=21" title="退换货原则">退换货原则</a></dd>
    <dd><a href="article.php?id=22" title="售后服务保证 ">售后服务保证</a></dd>
    <dd><a href="article.php?id=23" title="产品质量保证 ">产品质量保证</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=9' title="联系我们 ">联系我们 </a></dt>
    <dd><a href="article.php?id=24" title="网站故障报告">网站故障报告</a></dd>
    <dd><a href="article.php?id=25" title="选机咨询 ">选机咨询</a></dd>
    <dd><a href="article.php?id=26" title="投诉与建议 ">投诉与建议</a></dd>
  </dl>
   </div>
  </div>
</div>
<div class="blank"></div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="bNavList clearfix">
   <div class="f_l">
              <a href="article.php?id=1" >免责条款</a>
                   -
                      <a href="article.php?id=2" >隐私保护</a>
                   -
                      <a href="article.php?id=3" >咨询热点</a>
                   -
                      <a href="article.php?id=4" >联系我们</a>
                   -
                      <a href="article.php?id=5" >公司简介</a>
                   -
                      <a href="wholesale.php" >批发方案</a>
                   -
                      <a href="myship.php" >配送方式</a>
                   -
                      <a href="user.php?act=register&type=agent" >业务经理注册</a>
                   -
                      <a href="user.php?act=register&type=distributor" >经销商注册</a>
                   </div>
   <div class="f_r">
   <a href="#top"><img src="themes/default/images/bnt_top.gif" /></a> <a href="index.php"><img src="themes/default/images/bnt_home.gif" /></a>
   </div>
  </div>
 </div>
</div>
<div class="blank"></div>
<div id="footer">
 <div class="text">
 &copy; 2005-2011 ECSHOP 版权所有，并保留所有权利。<br />
                                                                                     <br />
    554fcae493e564ee0dc75bdf2ebf94caquery_info|a:1:{s:4:"name";s:10:"query_info";}554fcae493e564ee0dc75bdf2ebf94ca<br />
  <a href="http://www.ecshop.com" target="_blank" style=" font-family:Verdana; font-size:11px;">Powered&nbsp;by&nbsp;<strong><span style="color: #3366FF">ECShop</span>&nbsp;<span style="color: #FF9966">v2.7.2</span></strong></a>&nbsp;<br />
        <div align="left"  id="rss"><a href=""><img src="themes/default/images/xml_rss2.gif" alt="rss" /></a></div>
 </div>
</div>
</body>
<script type="text/javascript">
var goods_id = 24;
var goodsattr_style = 1;
var gmt_end_time = 0;
var day = "天";
var hour = "小时";
var minute = "分钟";
var second = "秒";
var end = "结束";
var goodsId = 24;
var now_time = 1305589417;
onload = function(){
  changePrice();
  fixpng();
  try {onload_leftTime();}
  catch (e) {}
}
/**
 * 点选可选属性或改变数量时修改商品价格的函数
 */
function changePrice()
{
  var attr = getSelectedAttributes(document.forms['ECS_FORMBUY']);
  var qty = document.forms['ECS_FORMBUY'].elements['number'].value;
  Ajax.call('goods.php', 'act=price&id=' + goodsId + '&attr=' + attr + '&number=' + qty, changePriceResponse, 'GET', 'JSON');
}
/**
 * 接收返回的信息
 */
function changePriceResponse(res)
{
  if (res.err_msg.length > 0)
  {
    alert(res.err_msg);
  }
  else
  {
    document.forms['ECS_FORMBUY'].elements['number'].value = res.qty;
    if (document.getElementById('ECS_GOODS_AMOUNT'))
      document.getElementById('ECS_GOODS_AMOUNT').innerHTML = res.result;
  }
}
</script>
</html>
