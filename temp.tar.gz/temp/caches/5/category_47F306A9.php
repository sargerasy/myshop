<?php exit;?>a:3:{s:8:"template";a:11:{i:0;s:53:"F:/xamp/xampp/htdocs/shop/themes/default/category.dwt";i:1;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_header.lbi";i:2;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/ur_here.lbi";i:3;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/cart.lbi";i:4;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/category_tree.lbi";i:5;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/history.lbi";i:6;s:67:"F:/xamp/xampp/htdocs/shop/themes/default/library/recommend_best.lbi";i:7;s:63:"F:/xamp/xampp/htdocs/shop/themes/default/library/goods_list.lbi";i:8;s:58:"F:/xamp/xampp/htdocs/shop/themes/default/library/pages.lbi";i:9;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/help.lbi";i:10;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_footer.lbi";}s:7:"expires";i:1293587735;s:8:"maketime";i:1293584135;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.2" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<title>GSM手机_手机类型_ECSHOP演示站 - Powered by ECShop</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/default/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/global.js"></script><script type="text/javascript" src="js/compare.js"></script></head>
<body>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div class="block clearfix">
 <div class="f_l"><a href="index.php" name="top"><img src="themes/default/images/logo.gif" /></a></div>
 <div class="f_r log">
   <ul>
   <li class="userInfo">
   <script type="text/javascript" src="js/transport.js"></script><script type="text/javascript" src="js/utils.js"></script>   <font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
   </li>
      <li id="topNav" class="clearfix">
                <a href="flow.php" >查看购物车</a>
                         |
                            <a href="pick_out.php" >选购中心</a>
                         |
                            <a href="tag_cloud.php" >标签云</a>
                         |
                            <a href="quotation.php" >报价单</a>
                         |
                            <a href="wholesale.php" >批发</a>
                    <div class="topNavR"></div>
   </li>
      </ul>
 </div>
</div>
<div  class="blank"></div>
<div id="mainNav" class="clearfix">
  <a href="index.php">首页<span></span></a>
    <a href="category.php?id=3"   class="cur">GSM手机<span></span></a>
   <a href="category.php?id=5"  >双模手机<span></span></a>
   <a href="category.php?id=6"  >手机配件<span></span></a>
   <a href="group_buy.php"  >团购商品<span></span></a>
   <a href="activity.php"  >优惠活动<span></span></a>
   <a href="snatch.php"  >夺宝奇兵<span></span></a>
   <a href="auction.php"  >拍卖活动<span></span></a>
   <a href="exchange.php"  >积分商城<span></span></a>
   <a href="message.php"  >留言板<span></span></a>
   <a href="http://bbs.ecshop.com/" target="_blank"  >EC论坛<span></span></a>
 </div>
<div id="search"  class="clearfix">
  <div class="keys f_l">
   <script type="text/javascript">
    
    <!--
    function checkSearchForm()
    {
        if(document.getElementById('keyword').value)
        {
            return true;
        }
        else
        {
            alert("请输入搜索关键词！");
            return false;
        }
    }
    -->
    
    </script>
      </div>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="f_r"  style="_position:relative; top:5px;">
   <select name="category" id="category" class="B_input">
      <option value="0">所有分类</option>
      <option value="1" >手机类型</option><option value="4" >&nbsp;&nbsp;&nbsp;&nbsp;3G手机</option><option value="5" >&nbsp;&nbsp;&nbsp;&nbsp;双模手机</option><option value="2" >&nbsp;&nbsp;&nbsp;&nbsp;CDMA手机</option><option value="3" >&nbsp;&nbsp;&nbsp;&nbsp;GSM手机</option><option value="12" >充值卡</option><option value="15" >&nbsp;&nbsp;&nbsp;&nbsp;联通手机充值卡</option><option value="13" >&nbsp;&nbsp;&nbsp;&nbsp;小灵通/固话充值卡</option><option value="14" >&nbsp;&nbsp;&nbsp;&nbsp;移动手机充值卡</option><option value="6" >手机配件</option><option value="8" >&nbsp;&nbsp;&nbsp;&nbsp;耳机</option><option value="9" >&nbsp;&nbsp;&nbsp;&nbsp;电池</option><option value="11" >&nbsp;&nbsp;&nbsp;&nbsp;读卡器和内存卡</option><option value="7" >&nbsp;&nbsp;&nbsp;&nbsp;充电器</option>    </select>
   <input name="keywords" type="text" id="keyword" value="" class="B_input" style="width:110px;"/>
   <input name="imageField" type="submit" value="" class="go" style="cursor:pointer;" />
   <a href="search.php?act=advanced_search">高级搜索</a>
   </form>
</div>
<div class="block box">
 <div id="ur_here">
  当前位置: <a href=".">首页</a> <code>&gt;</code> <a href="category.php?id=1">手机类型</a> <code>&gt;</code> <a href="category.php?id=3">GSM手机</a> </div>
</div>
<div class="blank"></div>
<div class="block clearfix">
  
  <div class="AreaL">
    
<div class="cart" id="ECS_CARTINFO">
 554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca</div>
<div class="blank5"></div>
<div class="box">
 <div class="box_1">
  <div id="category_tree">
         <dl>
     <dt><a href="category.php?id=2">CDMA手机</a></dt>
            
       </dl>
         <dl>
     <dt><a href="category.php?id=3">GSM手机</a></dt>
            
       </dl>
         <dl>
     <dt><a href="category.php?id=4">3G手机</a></dt>
            
       </dl>
         <dl>
     <dt><a href="category.php?id=5">双模手机</a></dt>
            
       </dl>
     
  </div>
 </div>
</div>
<div class="blank5"></div>
 <div class="box" id='history_div'>
 <div class="box_1">
  <h3><span>浏览历史</span></h3>
  <div class="boxCenterList clearfix" id='history_list'>
    554fcae493e564ee0dc75bdf2ebf94cahistory|a:1:{s:4:"name";s:7:"history";}554fcae493e564ee0dc75bdf2ebf94ca  </div>
 </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
if (document.getElementById('history_list').innerHTML.replace(/\s/g,'').length<1)
{
    document.getElementById('history_div').style.display='none';
}
else
{
    document.getElementById('history_div').style.display='block';
}
function clear_history()
{
Ajax.call('user.php', 'act=clear_history',clear_history_Response, 'GET', 'TEXT',1,1);
}
function clear_history_Response(res)
{
document.getElementById('history_list').innerHTML = '您已清空最近浏览过的商品';
}
</script>
    
  </div>
  
  
  <div class="AreaR">
	 
	  	  <div class="box">
		 <div class="box_1">
			<h3><span>商品筛选</span></h3>
						<div class="screeBox">
			  <strong>品牌：</strong>
														<span>全部</span>
																			<a href="category.php?id=3&amp;brand=1&amp;price_min=0&amp;price_max=0">诺基亚</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=2&amp;price_min=0&amp;price_max=0">摩托罗拉</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=3&amp;price_min=0&amp;price_max=0">多普达</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=4&amp;price_min=0&amp;price_max=0">飞利浦</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=5&amp;price_min=0&amp;price_max=0">夏新</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=6&amp;price_min=0&amp;price_max=0">三星</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=7&amp;price_min=0&amp;price_max=0">索爱</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=9&amp;price_min=0&amp;price_max=0">联想</a>&nbsp;
																			<a href="category.php?id=3&amp;brand=10&amp;price_min=0&amp;price_max=0">金立</a>&nbsp;
												</div>
									<div class="screeBox">
			<strong>价格：</strong>
											<span>全部</span>
															<a href="category.php?id=3&amp;price_min=200&amp;price_max=1700">200&nbsp;-&nbsp;1700</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=1700&amp;price_max=3200">1700&nbsp;-&nbsp;3200</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=4700&amp;price_max=6200">4700&nbsp;-&nbsp;6200</a>&nbsp;
										</div>
						      <div class="screeBox">
			<strong>颜色 :</strong>
											<span>全部</span>
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=167.0.0.0">灰色</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=198.0.0.0">白色</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=197.0.0.0">金色</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=163.0.0.0">黑色</a>&nbsp;
										</div>
            <div class="screeBox">
			<strong>屏幕大小 :</strong>
											<span>全部</span>
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.229.0.0">1.75英寸</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.216.0.0">2.0英寸</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.223.0.0">2.2英寸</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.156.0.0">2.6英寸</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.200.0.0">2.8英寸</a>&nbsp;
										</div>
            <div class="screeBox">
			<strong>手机制式 :</strong>
											<span>全部</span>
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.0.202.0">CDMA</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.0.160.0">GSM,850,900,1800,1900</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.0.195.0">GSM,900,1800,1900,2100</a>&nbsp;
										</div>
            <div class="screeBox">
			<strong>外观样式 :</strong>
											<span>全部</span>
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.0.0.199">滑盖</a>&nbsp;
															<a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;filter_attr=0.0.0.186">直板</a>&nbsp;
										</div>
      		 </div>
		</div>
		<div class="blank5"></div>
	  	 
   
<div class="box">
<div class="box_2 centerPadd">
  <div class="itemTit" id="itemBest">
        </div>
  <div id="show_best_area" class="clearfix goodsBox">
      <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=24"><img src="images/200905/thumb_img/24_thumb_G_1241971981429.jpg" alt="P806" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=24" title="P806">P806</a></p>
           <font class="f1">
                     ￥2000元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=9"><img src="images/200905/thumb_img/9_thumb_G_1241511871555.jpg" alt="诺基亚E66" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=9" title="诺基亚E66">诺基亚E66</a></p>
           <font class="f1">
                     ￥2298元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=8"><img src="images/200905/thumb_img/8_thumb_G_1241425513488.jpg" alt="飞利浦9@9v" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=8" title="飞利浦9@9v">飞利浦9@9v</a></p>
           <font class="f1">
                     ￥399元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=17"><img src="images/200905/thumb_img/17_thumb_G_1241969394587.jpg" alt="夏新N7" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=17" title="夏新N7">夏新N7</a></p>
           <font class="f1">
                     ￥2300元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=19"><img src="images/200905/thumb_img/19_thumb_G_1241970175208.jpg" alt="三星SGH-F258" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=19" title="三星SGH-F258">三星SGH-F...</a></p>
           <font class="f1">
                     ￥858元                     </font>
        </div>
    <div class="more"><a href="search.php?intro=best"><img src="themes/default/images/more.gif" /></a></div>
    </div>
</div>
</div>
<div class="blank5"></div>
    <div class="box">
 <div class="box_1">
  <h3>
  <span>商品列表</span><a name='goods_list'></a>
  <form method="GET" class="sort" name="listform">
  显示方式：
  <a href="javascript:;" onClick="javascript:display_mode('list')"><img src="themes/default/images/display_mode_list.gif" alt=""></a>
  <a href="javascript:;" onClick="javascript:display_mode('grid')"><img src="themes/default/images/display_mode_grid.gif" alt=""></a>
  <a href="javascript:;" onClick="javascript:display_mode('text')"><img src="themes/default/images/display_mode_text_act.gif" alt=""></a>&nbsp;&nbsp;
  
  <a href="category.php?category=3&display=text&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=goods_id&order=ASC#goods_list"><img src="themes/default/images/goods_id_DESC.gif" alt="按上架时间排序"></a>
  <a href="category.php?category=3&display=text&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=shop_price&order=ASC#goods_list"><img src="themes/default/images/shop_price_default.gif" alt="按价格排序"></a>
  <a href="category.php?category=3&display=text&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=last_update&order=DESC#goods_list"><img src="themes/default/images/last_update_default.gif" alt="按更新时间排序"></a>
  <input type="hidden" name="category" value="3" />
  <input type="hidden" name="display" value="text" id="display" />
  <input type="hidden" name="brand" value="0" />
  <input type="hidden" name="price_min" value="0" />
  <input type="hidden" name="price_max" value="0" />
  <input type="hidden" name="filter_attr" value="0" />
  <input type="hidden" name="page" value="1" />
  <input type="hidden" name="sort" value="goods_id" />
  <input type="hidden" name="order" value="DESC" />
  </form>
  </h3>
      <form name="compareForm" action="compare.php" method="post" onSubmit="return compareGoods(this);">
            <div class="goodsList">
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(32,'诺基亚N85','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=32" class="f6 f5">
                诺基亚N85<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥3612元</font><br />
            本店售价：<font class="shop">￥3010元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(32);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(32)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(24,'P806','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=24" class="f6 f5">
                P806<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥2400元</font><br />
            本店售价：<font class="shop">￥2000元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(24);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(24)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(22,'多普达Touch HD','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=22" class="f6 f5">
                多普达Touch HD<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥7199元</font><br />
            本店售价：<font class="shop">￥5999元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(22);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(22)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(21,'金立 A30','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=21" class="f6 f5">
                金立 A30<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥2400元</font><br />
            本店售价：<font class="shop">￥2000元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(21);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(21)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(20,'三星BC01','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=20" class="f6 f5">
                三星BC01<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥336元</font><br />
            本店售价：<font class="shop">￥280元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(20);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(20)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(19,'三星SGH-F258','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=19" class="f6 f5">
                三星SGH-F258<br />
              </a>
         商品描述：从整体来看，三星SGH-F258比较时尚可爱，三围尺寸为94×46×17.5mm，重量为96克，曲线柔和具有玲珑美感
<br />
        </li>
    <li>
        市场价格：<font class="market">￥1030元</font><br />
            本店售价：<font class="shop">￥858元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(19);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(19)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(17,'夏新N7','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=17" class="f6 f5">
                夏新N7<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥2760元</font><br />
            本店售价：<font class="shop">￥2300元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(17);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(17)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(13,'诺基亚5320 XpressMusic','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=13" class="f6 f5">
                诺基亚5320 XpressMusic<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥1573元</font><br />
            本店售价：<font class="shop">￥1311元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(13);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(13)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(12,'摩托罗拉A810','3')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=12" class="f6 f5">
                摩托罗拉A810<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥1180元</font><br />
            本店售价：<font class="shop">￥983元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(12);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(12)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
         <ul class="clearfix bgcolor"id="bgcolor">
    <li style="margin-right:15px;">
    <a href="javascript:;" id="compareLink" onClick="Compare.add(10,'索爱C702c','9')" class="f6">比较</a>
    </li>
    <li class="goodsName">
    <a href="goods.php?id=10" class="f6 f5">
                索爱C702c<br />
              </a>
         </li>
    <li>
        市场价格：<font class="market">￥1594元</font><br />
            本店售价：<font class="shop">￥1328元</font><br />
        </li>
    <li class="action">
    <a href="javascript:collect(10);" class="abg f6">收藏该商品</a>
    <a href="javascript:addToCart(10)"><img src="themes/default/images/bnt_buy_1.gif"></a>
    </li>
    </ul>
        </div>
        </form>
  
 </div>
</div>
<div class="blank5"></div>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script>
<script type="text/javascript">
window.onload = function()
{
  Compare.init();
  fixpng();
}
var button_compare = '';
var exist = "您已经选择了%s";
var count_limit = "最多只能选择4个商品进行对比";
var goods_type_different = "\"%s\"和已选择商品类型不同无法进行对比";
var compare_no_goods = "您没有选定任何需要比较的商品或者比较的商品数少于 2 个。";
var btn_buy = "购买";
var is_cancel = "取消";
var select_spe = "请选择商品属性";
</script>  <form name="selectPageForm" action="/shop/category.php" method="get">
 <div id="pager" class="pagebar">
  <span class="f_l f6" style="margin-right:10px;">总计 <b>12</b>  个记录</span>
                      <span class="page_now">1</span>
                      <a href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;page=2&amp;sort=goods_id&amp;order=DESC">[2]</a>
            
  <a class="next" href="category.php?id=3&amp;price_min=0&amp;price_max=0&amp;page=2&amp;sort=goods_id&amp;order=DESC">下一页</a>    </div>
</form>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script>
  </div>  
  
</div>
<div class="blank5"></div>
<div class="block">
  <div class="box">
   <div class="helpTitBg clearfix">
    <dl>
  <dt><a href='article_cat.php?id=5' title="新手上路 ">新手上路 </a></dt>
    <dd><a href="article.php?id=9" title="售后流程">售后流程</a></dd>
    <dd><a href="article.php?id=10" title="购物流程">购物流程</a></dd>
    <dd><a href="article.php?id=11" title="订购方式">订购方式</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=6' title="手机常识 ">手机常识 </a></dt>
    <dd><a href="article.php?id=12" title="如何分辨原装电池">如何分辨原装电池</a></dd>
    <dd><a href="article.php?id=13" title="如何分辨水货手机 ">如何分辨水货手机</a></dd>
    <dd><a href="article.php?id=14" title="如何享受全国联保">如何享受全国联保</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=7' title="配送与支付 ">配送与支付 </a></dt>
    <dd><a href="article.php?id=15" title="货到付款区域">货到付款区域</a></dd>
    <dd><a href="article.php?id=16" title="配送支付智能查询 ">配送支付智能查询</a></dd>
    <dd><a href="article.php?id=17" title="支付方式说明">支付方式说明</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=10' title="会员中心">会员中心</a></dt>
    <dd><a href="article.php?id=18" title="资金管理">资金管理</a></dd>
    <dd><a href="article.php?id=19" title="我的收藏">我的收藏</a></dd>
    <dd><a href="article.php?id=20" title="我的订单">我的订单</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=8' title="服务保证 ">服务保证 </a></dt>
    <dd><a href="article.php?id=21" title="退换货原则">退换货原则</a></dd>
    <dd><a href="article.php?id=22" title="售后服务保证 ">售后服务保证</a></dd>
    <dd><a href="article.php?id=23" title="产品质量保证 ">产品质量保证</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=9' title="联系我们 ">联系我们 </a></dt>
    <dd><a href="article.php?id=24" title="网站故障报告">网站故障报告</a></dd>
    <dd><a href="article.php?id=25" title="选机咨询 ">选机咨询</a></dd>
    <dd><a href="article.php?id=26" title="投诉与建议 ">投诉与建议</a></dd>
  </dl>
   </div>
  </div>  
</div>
<div class="blank"></div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="bNavList clearfix">
   <div class="f_l">
              <a href="article.php?id=1" >免责条款</a>
                   -
                      <a href="article.php?id=2" >隐私保护</a>
                   -
                      <a href="article.php?id=3" >咨询热点</a>
                   -
                      <a href="article.php?id=4" >联系我们</a>
                   -
                      <a href="article.php?id=5" >公司简介</a>
                   -
                      <a href="wholesale.php" >批发方案</a>
                   -
                      <a href="myship.php" >配送方式</a>
                   </div>
   <div class="f_r">
   <a href="#top"><img src="themes/default/images/bnt_top.gif" /></a> <a href="index.php"><img src="themes/default/images/bnt_home.gif" /></a>
   </div>
  </div>
 </div>
</div>
<div class="blank"></div>
<div id="footer">
 <div class="text">
 &copy; 2005-2010 ECSHOP 版权所有，并保留所有权利。<br />
                                                                                     <br />
    554fcae493e564ee0dc75bdf2ebf94caquery_info|a:1:{s:4:"name";s:10:"query_info";}554fcae493e564ee0dc75bdf2ebf94ca<br />
  <a href="http://www.ecshop.com" target="_blank" style=" font-family:Verdana; font-size:11px;">Powered&nbsp;by&nbsp;<strong><span style="color: #3366FF">ECShop</span>&nbsp;<span style="color: #FF9966">v2.7.2</span></strong></a>&nbsp;<br />
        <div align="left"  id="rss"><a href="feed.php?cat=3"><img src="themes/default/images/xml_rss2.gif" alt="rss" /></a></div>
 </div>
</div>
</body>
</html>