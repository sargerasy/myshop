<?php exit;?>a:3:{s:8:"template";a:1:{i:0;s:45:"F:/xamp/xampp/htdocs/shop/data/affiliate.html";}s:7:"expires";i:1293587751;s:8:"maketime";i:1293584151;}<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%">
      <tr>
        <td align="center"><a href="http://localhost/shop/goods.php?u=6&id=24" target="_blank"><img src="http://localhost/shop/images/200905/thumb_img/24_thumb_G_1241971981429.jpg" alt="P806" border="0"></a></td>
      </tr>
      <tr>
        <td align="center"><a href="http://localhost/shop/goods.php?u=6&id=24" target="_blank"><big>P806</big></a><br /><s>￥2400元</s> <font color = "#FF0000">￥2000元</font></td>
      </tr>
    </table></td>
  </tr>
</table>
