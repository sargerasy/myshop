<?php exit;?>a:3:{s:8:"template";a:21:{i:0;s:50:"F:/xamp/xampp/htdocs/shop/themes/default/index.dwt";i:1;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_header.lbi";i:2;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/cart.lbi";i:3;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/category_tree.lbi";i:4;s:58:"F:/xamp/xampp/htdocs/shop/themes/default/library/top10.lbi";i:5;s:67:"F:/xamp/xampp/htdocs/shop/themes/default/library/promotion_info.lbi";i:6;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/order_query.lbi";i:7;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/invoice_query.lbi";i:8;s:62:"F:/xamp/xampp/htdocs/shop/themes/default/library/vote_list.lbi";i:9;s:63:"F:/xamp/xampp/htdocs/shop/themes/default/library/email_list.lbi";i:10;s:61:"F:/xamp/xampp/htdocs/shop/themes/default/library/index_ad.lbi";i:11;s:65:"F:/xamp/xampp/htdocs/shop/themes/default/library/new_articles.lbi";i:12;s:72:"F:/xamp/xampp/htdocs/shop/themes/default/library/recommend_promotion.lbi";i:13;s:59:"F:/xamp/xampp/htdocs/shop/themes/default/library/brands.lbi";i:14;s:67:"F:/xamp/xampp/htdocs/shop/themes/default/library/recommend_best.lbi";i:15;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/recommend_new.lbi";i:16;s:66:"F:/xamp/xampp/htdocs/shop/themes/default/library/recommend_hot.lbi";i:17;s:60:"F:/xamp/xampp/htdocs/shop/themes/default/library/auction.lbi";i:18;s:62:"F:/xamp/xampp/htdocs/shop/themes/default/library/group_buy.lbi";i:19;s:57:"F:/xamp/xampp/htdocs/shop/themes/default/library/help.lbi";i:20;s:64:"F:/xamp/xampp/htdocs/shop/themes/default/library/page_footer.lbi";}s:7:"expires";i:1305605712;s:8:"maketime";i:1305602112;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="Generator" content="ECSHOP v2.7.2" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="ECSHOP演示站" />
<meta name="Description" content="ECSHOP演示站" />
<title>ECSHOP演示站 - Powered by ECShop</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/default/style.css" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="RSS|ECSHOP演示站 - Powered by ECShop" href="feed.php" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/index.js"></script></head>
<body>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div class="block clearfix">
 <div class="f_l"><a href="index.php" name="top"><img src="themes/default/images/logo.gif" /></a></div>
 <div class="f_r log">
   <ul>
   <li class="userInfo">
   <script type="text/javascript" src="js/transport.js"></script><script type="text/javascript" src="js/utils.js"></script>   <font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
   </li>
      <li id="topNav" class="clearfix">
    			            <a href="flow.php" >查看购物车</a>
                         |
            			    			            <a href="pick_out.php" >选购中心</a>
                         |
            			    			            <a href="tag_cloud.php" >标签云</a>
                         |
            			    						    			            <a href="quotation.php" >报价单</a>
            			        <div class="topNavR"></div>
   </li>
      </ul>
 </div>
</div>
<div  class="blank"></div>
<div id="mainNav" class="clearfix">
  <a href="index.php" class="cur">首页<span></span></a>
    <a href="category.php?id=3"  >GSM手机<span></span></a>
   <a href="category.php?id=5"  >双模手机<span></span></a>
   <a href="category.php?id=6"  >手机配件<span></span></a>
   <a href="group_buy.php"  >团购商品<span></span></a>
   <a href="activity.php"  >优惠活动<span></span></a>
   <a href="snatch.php"  >夺宝奇兵<span></span></a>
   <a href="auction.php"  >拍卖活动<span></span></a>
   <a href="exchange.php"  >积分商城<span></span></a>
   <a href="message.php"  >留言板<span></span></a>
   <a href="http://bbs.ecshop.com/" target="_blank"  >EC论坛<span></span></a>
 </div>
<div id="search"  class="clearfix">
  <div class="keys f_l">
   <script type="text/javascript">
    
    <!--
    function checkSearchForm()
    {
        if(document.getElementById('keyword').value)
        {
            return true;
        }
        else
        {
            alert("请输入搜索关键词！");
            return false;
        }
    }
    -->
    
    </script>
      </div>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()" class="f_r"  style="_position:relative; top:5px;">
   <select name="category" id="category" class="B_input">
      <option value="0">所有分类</option>
      <option value="12" >充值卡</option><option value="15" >&nbsp;&nbsp;&nbsp;&nbsp;联通手机充值卡</option><option value="13" >&nbsp;&nbsp;&nbsp;&nbsp;小灵通/固话充值卡</option><option value="14" >&nbsp;&nbsp;&nbsp;&nbsp;移动手机充值卡</option><option value="6" >手机配件</option><option value="8" >&nbsp;&nbsp;&nbsp;&nbsp;耳机</option><option value="9" >&nbsp;&nbsp;&nbsp;&nbsp;电池</option><option value="11" >&nbsp;&nbsp;&nbsp;&nbsp;读卡器和内存卡</option><option value="7" >&nbsp;&nbsp;&nbsp;&nbsp;充电器</option><option value="1" >手机类型</option><option value="5" >&nbsp;&nbsp;&nbsp;&nbsp;双模手机</option><option value="2" >&nbsp;&nbsp;&nbsp;&nbsp;CDMA手机</option><option value="3" >&nbsp;&nbsp;&nbsp;&nbsp;GSM手机</option><option value="4" >&nbsp;&nbsp;&nbsp;&nbsp;3G手机</option>    </select>
   <input name="keywords" type="text" id="keyword" value="" class="B_input" style="width:110px;"/>
   <input name="imageField" type="submit" value="" class="go" style="cursor:pointer;" />
   <a href="search.php?act=advanced_search">高级搜索</a>
   </form>
</div>
<div class="blank"></div>
<div class="block clearfix">
  
  <div class="AreaL">
    
    <div class="box">
     <div class="box_1">
      <h3><span>商店公告</span></h3>
      <div class="boxCenterList RelaArticle">
        欢迎光临手机网,我们的宗旨：诚信经营、服务客户！
<MARQUEE onmouseover=this.stop() onmouseout=this.start() 
scrollAmount=3><U><FONT color=red>
<P>咨询电话010-10124444  010-21252454 8465544</P></FONT></U></MARQUEE>      </div>
     </div>
    </div>
    <div class="blank5"></div>
    
  
<div class="cart" id="ECS_CARTINFO">
 554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca</div>
<div class="blank5"></div>
<div class="box">
 <div class="box_1">
  <div id="category_tree">
         <dl>
     <dt><a href="category.php?id=1">手机类型</a></dt>
          <dd><a href="category.php?id=2">CDMA手机</a></dd>
                 <dd><a href="category.php?id=3">GSM手机</a></dd>
                 <dd><a href="category.php?id=4">3G手机</a></dd>
                 <dd><a href="category.php?id=5">双模手机</a></dd>
                   
       </dl>
         <dl>
     <dt><a href="category.php?id=6">手机配件</a></dt>
          <dd><a href="category.php?id=7">充电器</a></dd>
                 <dd><a href="category.php?id=8">耳机</a></dd>
              <dd>&nbsp;&nbsp;<a href="category.php?id=16">123</a></dd>
                 <dd><a href="category.php?id=9">电池</a></dd>
                 <dd><a href="category.php?id=11">读卡器和内存卡</a></dd>
                   
       </dl>
         <dl>
     <dt><a href="category.php?id=12">充值卡</a></dt>
          <dd><a href="category.php?id=13">小灵通/固话充值卡</a></dd>
                 <dd><a href="category.php?id=14">移动手机充值卡</a></dd>
                 <dd><a href="category.php?id=15">联通手机充值卡</a></dd>
                   
       </dl>
     
  </div>
 </div>
</div>
<div class="blank5"></div>
<div class="box">
 <div class="box_2">
  <div class="top10Tit"></div>
  <div class="top10List clearfix">
    </div>
 </div>
</div>
<div class="blank5"></div>
<div class="box">
 <div class="box_1">
  <h3><span>促销信息</span></h3>
  <div class="boxCenterList RelaArticle">
            <a href="group_buy.php" title="团购活动">[团购]</a>
        <a href="group_buy.php?act=view&amp;id=8" title="团购活动 P806的时间为2009-05-15到2011-05-26，赶快来抢吧！" style="background:none; padding-left:0px;">P806</a><br />
      </div>
 </div>
</div>
<div class="blank5"></div>
<script>var invalid_order_sn = "无效订单号"</script>
<div class="box">
 <div class="box_1">
  <h3><span>订单查询</span></h3>
  <div class="boxCenterList">
    <form name="ecsOrderQuery">
    <input type="text" name="order_sn" class="inputBg" /><br />
    <div class="blank5"></div>
    <input type="button" value="查询该订单号" class="bnt_blue_2" onclick="orderQuery()" />
    </form>
    <div id="ECS_ORDER_QUERY" style="margin-top:8px;">
          </div>
  </div>
 </div>
</div>
<div class="blank5"></div>
554fcae493e564ee0dc75bdf2ebf94cavote|a:1:{s:4:"name";s:4:"vote";}554fcae493e564ee0dc75bdf2ebf94ca<div class="box">
 <div class="box_1">
  <h3><span>邮件订阅</span></h3>
  <div class="boxCenterList RelaArticle">
    <input type="text" id="user_email" class="inputBg" /><br />
    <div class="blank5"></div>
    <input type="button" class="bnt_blue" value="订阅" onclick="add_email_list();" />
    <input type="button" class="bnt_bonus"  value="退订" onclick="cancel_email_list();" />
  </div>
 </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
var email = document.getElementById('user_email');
function add_email_list()
{
  if (check_email())
  {
    Ajax.call('user.php?act=email_list&job=add&email=' + email.value, '', rep_add_email_list, 'GET', 'TEXT');
  }
}
function rep_add_email_list(text)
{
  alert(text);
}
function cancel_email_list()
{
  if (check_email())
  {
    Ajax.call('user.php?act=email_list&job=del&email=' + email.value, '', rep_cancel_email_list, 'GET', 'TEXT');
  }
}
function rep_cancel_email_list(text)
{
  alert(text);
}
function check_email()
{
  if (Utils.isEmail(email.value))
  {
    return true;
  }
  else
  {
    alert('邮件地址非法！');
    return false;
  }
}
</script>
  </div>
  
  
  <div class="AreaR">
   
    <div class="box clearfix">
     <div class="box_1 clearfix">
       <div class="f_l" id="focus">
         <script type="text/javascript">
  var swf_width=484;
  var swf_height=200;
  </script>
  <script type="text/javascript" src="data/flashdata/dynfocus/cycle_image.js"></script>
       </div>
       
       <div id="mallNews" class="f_r">
        <div class="NewsTit"></div>
        <div class="NewsList tc">
         
        <ul>
  <li>
	[<a href="article_cat.php?id=12">站内快讯</a>] <a href="article.php?id=33" title="三星SGHU308说明书下载">三星SGHU308说...</a>
	</li>
  <li>
	[<a href="article_cat.php?id=12">站内快讯</a>] <a href="article.php?id=32" title="手机游戏下载">手机游戏下载</a>
	</li>
  <li>
	[<a href="article_cat.php?id=11">手机促销</a>] <a href="article.php?id=30" title="促销诺基亚N96">促销诺基亚N96</a>
	</li>
  <li>
	[<a href="article_cat.php?id=11">手机促销</a>] <a href="article.php?id=29" title="诺基亚5320 促销">诺基亚5320 促销</a>
	</li>
  <li>
	[<a href="article_cat.php?id=12">站内快讯</a>] <a href="article.php?id=34" title="3G知识普及">3G知识普及</a>
	</li>
  <li>
	[<a href="article_cat.php?id=12">站内快讯</a>] <a href="article.php?id=31" title="诺基亚6681手机广告欣赏">诺基亚6681手机广...</a>
	</li>
  <li>
	[<a href="article_cat.php?id=11">手机促销</a>] <a href="article.php?id=28" title="飞利浦9@9促销">飞利浦9@9促销</a>
	</li>
  <li>
	[<a href="article_cat.php?id=4">3G资讯</a>] <a href="article.php?id=27" title="800万像素超强拍照机 LG Viewty Smart再曝光">800万像素超强拍照...</a>
	</li>
</ul>        </div>
       </div>
       
     </div>
    </div>
    <div class="blank5"></div>
   
   
    <div class="clearfix">
      
            
      <div class="box f_r brandsIe6">
       <div class="box_1 clearfix" id="brands">
                            <a href="brand.php?id=1"><img src="data/brandlogo/1240803062307572427.gif" alt="诺基亚 (7)" /></a>
                              <a href="brand.php?id=2"><img src="data/brandlogo/1240802922410634065.gif" alt="摩托罗拉 (1)" /></a>
                              <a href="brand.php?id=3"><img src="data/brandlogo/1240803144788047486.gif" alt="多普达 (1)" /></a>
                              <a href="brand.php?id=4"><img src="data/brandlogo/1240803247838195732.gif" alt="飞利浦 (1)" /></a>
                              <a href="brand.php?id=5"><img src="data/brandlogo/1240803352280856940.gif" alt="夏新 (1)" /></a>
                              <a href="brand.php?id=6"><img src="data/brandlogo/1240803412367015368.gif" alt="三星 (2)" /></a>
                              <a href="brand.php?id=7"><img src="data/brandlogo/1240803482283160654.gif" alt="索爱 (2)" /></a>
                              <a href="brand.php?id=8"><img src="data/brandlogo/1240803526904622792.gif" alt="LG (1)" /></a>
                              <a href="brand.php?id=9"><img src="data/brandlogo/1240803578417877983.gif" alt="联想 (1)" /></a>
                              <a href="brand.php?id=10">金立 (1)</a>
            <div class="brandsMore"><a href="brand.php"><img src="themes/default/images/moreBrands.gif" /></a></div>
       </div>
      </div>
    </div>
    <div class="blank5"></div>
   
<div class="box">
<div class="box_2 centerPadd">
  <div class="itemTit" id="itemBest">
            <h2><a href="javascript:void(0)" onclick="change_tab_style('itemBest', 'h2', this);get_cat_recommend(1, 0);">全部商品</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemBest', 'h2', this);get_cat_recommend(1, 3)">GSM手机</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemBest', 'h2', this);get_cat_recommend(1, 5)">双模手机</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemBest', 'h2', this);get_cat_recommend(1, 12)">充值卡</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemBest', 'h2', this);get_cat_recommend(1, 15)">联通手机充值卡</a></h2>
              </div>
  <div id="show_best_area" class="clearfix goodsBox">
      <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=24"><img src="images/200905/thumb_img/24_thumb_G_1241971981429.jpg" alt="P806" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=24" title="P806">P806</a></p>
           <font class="f1">
                     ￥2000元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=9"><img src="images/200905/thumb_img/9_thumb_G_1241511871555.jpg" alt="诺基亚E66" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=9" title="诺基亚E66">诺基亚E66</a></p>
           <font class="f1">
                     ￥2298元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=1"><img src="images/200905/thumb_img/1_thumb_G_1240902890710.jpg" alt="KD876" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=1" title="KD876">KD876</a></p>
           <font class="f1">
                     ￥1388元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=8"><img src="images/200905/thumb_img/8_thumb_G_1241425513488.jpg" alt="飞利浦9@9v" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=8" title="飞利浦9@9v">飞利浦9@9v</a></p>
           <font class="f1">
                     ￥399元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=17"><img src="images/200905/thumb_img/17_thumb_G_1241969394587.jpg" alt="夏新N7" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=17" title="夏新N7">夏新N7</a></p>
           <font class="f1">
                     ￥2300元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=19"><img src="images/200905/thumb_img/19_thumb_G_1241970175208.jpg" alt="三星SGH-F258" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=19" title="三星SGH-F258">三星SGH-F...</a></p>
           <font class="f1">
                     ￥858元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=20"><img src="images/200905/thumb_img/20_thumb_G_1242106490058.jpg" alt="三星BC01" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=20" title="三星BC01">三星BC01</a></p>
           <font class="f1">
                     ￥280元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=22"><img src="images/200905/thumb_img/22_thumb_G_1241971076803.jpg" alt="多普达Touch HD" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=22" title="多普达Touch HD">多普达Touc...</a></p>
           <font class="f1">
                     ￥5999元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=23"><img src="images/200905/thumb_img/23_thumb_G_1241971556399.jpg" alt="诺基亚N96" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=23" title="诺基亚N96">诺基亚N96</a></p>
           <font class="f1">
                     ￥3700元                     </font>
        </div>
    <div class="goodsItem">
         <span class="best"></span>
           <a href="goods.php?id=27"><img src="images/200905/thumb_img/27_thumb_G_1241972894068.jpg" alt="联通100元充值卡" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=27" title="联通100元充值卡">联通100元充...</a></p>
           <font class="f1">
                     ￥95元                     </font>
        </div>
    <div class="more"><a href="search.php?intro=best"><img src="themes/default/images/more.gif" /></a></div>
    </div>
</div>
</div>
<div class="blank5"></div>
  <div class="box">
<div class="box_2 centerPadd">
  <div class="itemTit New" id="itemNew">
            <h2><a href="javascript:void(0)" onclick="change_tab_style('itemNew', 'h2', this);get_cat_recommend(2, 0);">全部商品</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemNew', 'h2', this);get_cat_recommend(2, 3)">GSM手机</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemNew', 'h2', this);get_cat_recommend(2, 5)">双模手机</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemNew', 'h2', this);get_cat_recommend(2, 12)">充值卡</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemNew', 'h2', this);get_cat_recommend(2, 14)">移动手机充值卡</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemNew', 'h2', this);get_cat_recommend(2, 15)">联通手机充值卡</a></h2>
              </div>
  <div id="show_new_area" class="clearfix goodsBox">
      <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=24"><img src="images/200905/thumb_img/24_thumb_G_1241971981429.jpg" alt="P806" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=24" title="P806">P806</a></p>
           <font class="f1">
                     ￥2000元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=32"><img src="images/200905/thumb_img/32_thumb_G_1242110760196.jpg" alt="诺基亚N85" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=32" title="诺基亚N85">诺基亚N85</a></p>
           <font class="f1">
                     ￥3010元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=9"><img src="images/200905/thumb_img/9_thumb_G_1241511871555.jpg" alt="诺基亚E66" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=9" title="诺基亚E66">诺基亚E66</a></p>
           <font class="f1">
                     ￥2298元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=1"><img src="images/200905/thumb_img/1_thumb_G_1240902890710.jpg" alt="KD876" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=1" title="KD876">KD876</a></p>
           <font class="f1">
                     ￥1388元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=8"><img src="images/200905/thumb_img/8_thumb_G_1241425513488.jpg" alt="飞利浦9@9v" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=8" title="飞利浦9@9v">飞利浦9@9v</a></p>
           <font class="f1">
                     ￥399元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=19"><img src="images/200905/thumb_img/19_thumb_G_1241970175208.jpg" alt="三星SGH-F258" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=19" title="三星SGH-F258">三星SGH-F...</a></p>
           <font class="f1">
                     ￥858元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=20"><img src="images/200905/thumb_img/20_thumb_G_1242106490058.jpg" alt="三星BC01" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=20" title="三星BC01">三星BC01</a></p>
           <font class="f1">
                     ￥280元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=22"><img src="images/200905/thumb_img/22_thumb_G_1241971076803.jpg" alt="多普达Touch HD" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=22" title="多普达Touch HD">多普达Touc...</a></p>
           <font class="f1">
                     ￥5999元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=23"><img src="images/200905/thumb_img/23_thumb_G_1241971556399.jpg" alt="诺基亚N96" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=23" title="诺基亚N96">诺基亚N96</a></p>
           <font class="f1">
                     ￥3700元                     </font>
        </div>
    <div class="goodsItem">
         <span class="news"></span>
           <a href="goods.php?id=12"><img src="images/200905/thumb_img/12_thumb_G_1241965978410.jpg" alt="摩托罗拉A810" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=12" title="摩托罗拉A810">摩托罗拉A81...</a></p>
           <font class="f1">
                     ￥983元                     </font>
        </div>
    <div class="more"><a href="search.php?intro=new"><img src="themes/default/images/more.gif" /></a></div>
    </div>
</div>
</div>
<div class="blank5"></div>
  <div class="box">
<div class="box_2 centerPadd">
  <div class="itemTit Hot" id="itemHot">
            <h2><a href="javascript:void(0)" onclick="change_tab_style('itemHot', 'h2', this);get_cat_recommend(3, 0);">全部商品</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemHot', 'h2', this);get_cat_recommend(3, 3)">GSM手机</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemHot', 'h2', this);get_cat_recommend(3, 5)">双模手机</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemHot', 'h2', this);get_cat_recommend(3, 12)">充值卡</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemHot', 'h2', this);get_cat_recommend(3, 13)">小灵通/固话充值卡</a></h2>
            <h2 class="h2bg"><a href="javascript:void(0)" onclick="change_tab_style('itemHot', 'h2', this);get_cat_recommend(3, 14)">移动手机充值卡</a></h2>
              </div>
  <div id="show_hot_area" class="clearfix goodsBox">
      <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=24"><img src="images/200905/thumb_img/24_thumb_G_1241971981429.jpg" alt="P806" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=24" title="P806">P806</a></p>
           <font class="f1">
                     ￥2000元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=32"><img src="images/200905/thumb_img/32_thumb_G_1242110760196.jpg" alt="诺基亚N85" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=32" title="诺基亚N85">诺基亚N85</a></p>
           <font class="f1">
                     ￥3010元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=9"><img src="images/200905/thumb_img/9_thumb_G_1241511871555.jpg" alt="诺基亚E66" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=9" title="诺基亚E66">诺基亚E66</a></p>
           <font class="f1">
                     ￥2298元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=1"><img src="images/200905/thumb_img/1_thumb_G_1240902890710.jpg" alt="KD876" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=1" title="KD876">KD876</a></p>
           <font class="f1">
                     ￥1388元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=8"><img src="images/200905/thumb_img/8_thumb_G_1241425513488.jpg" alt="飞利浦9@9v" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=8" title="飞利浦9@9v">飞利浦9@9v</a></p>
           <font class="f1">
                     ￥399元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=13"><img src="images/200905/thumb_img/13_thumb_G_1241968002527.jpg" alt="诺基亚5320 XpressMusic" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=13" title="诺基亚5320 XpressMusic">诺基亚5320...</a></p>
           <font class="f1">
                     ￥1311元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=14"><img src="images/200905/thumb_img/14_thumb_G_1241968492116.jpg" alt="诺基亚5800XM" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=14" title="诺基亚5800XM">诺基亚5800...</a></p>
           <font class="f1">
                     ￥2625元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=17"><img src="images/200905/thumb_img/17_thumb_G_1241969394587.jpg" alt="夏新N7" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=17" title="夏新N7">夏新N7</a></p>
           <font class="f1">
                     ￥2300元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=19"><img src="images/200905/thumb_img/19_thumb_G_1241970175208.jpg" alt="三星SGH-F258" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=19" title="三星SGH-F258">三星SGH-F...</a></p>
           <font class="f1">
                     ￥858元                     </font>
        </div>
    <div class="goodsItem">
         <span class="hot"></span>
           <a href="goods.php?id=20"><img src="images/200905/thumb_img/20_thumb_G_1242106490058.jpg" alt="三星BC01" class="goodsimg" /></a><br />
           <p><a href="goods.php?id=20" title="三星BC01">三星BC01</a></p>
           <font class="f1">
                     ￥280元                     </font>
        </div>
    <div class="more"><a href="search.php?intro=hot"><img src="themes/default/images/more.gif" /></a></div>
    </div>
</div>
</div>
<div class="blank5"></div>
  <div class="box">
 <div class="box_1">
  <h3><span>团购商品</span><a href="group_buy.php"><img src="themes/default/images/more.gif"></a></h3>
    <div class="centerPadd">
    <div class="clearfix goodsBox" style="border:none;">
            <div class="goodsItem">
           <a href="group_buy.php?act=view&amp;id=8"><img src="images/200905/thumb_img/24_thumb_G_1241971981429.jpg" alt="P806" class="goodsimg" /></a><br />
					 <p><a href="group_buy.php?act=view&amp;id=8" title="P806">P806</a></p>
           <font class="shop_s">￥1860元</font>
        </div>
          </div>
    </div>
 </div>
</div>
<div class="blank5"></div>
  </div>
  
</div>
<div class="blank5"></div>
<div class="block">
  <div class="box">
   <div class="helpTitBg clearfix">
    <dl>
  <dt><a href='article_cat.php?id=5' title="新手上路 ">新手上路 </a></dt>
    <dd><a href="article.php?id=9" title="售后流程">售后流程</a></dd>
    <dd><a href="article.php?id=10" title="购物流程">购物流程</a></dd>
    <dd><a href="article.php?id=11" title="订购方式">订购方式</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=6' title="手机常识 ">手机常识 </a></dt>
    <dd><a href="article.php?id=12" title="如何分辨原装电池">如何分辨原装电池</a></dd>
    <dd><a href="article.php?id=13" title="如何分辨水货手机 ">如何分辨水货手机</a></dd>
    <dd><a href="article.php?id=14" title="如何享受全国联保">如何享受全国联保</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=7' title="配送与支付 ">配送与支付 </a></dt>
    <dd><a href="article.php?id=15" title="货到付款区域">货到付款区域</a></dd>
    <dd><a href="article.php?id=16" title="配送支付智能查询 ">配送支付智能查询</a></dd>
    <dd><a href="article.php?id=17" title="支付方式说明">支付方式说明</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=10' title="会员中心">会员中心</a></dt>
    <dd><a href="article.php?id=18" title="资金管理">资金管理</a></dd>
    <dd><a href="article.php?id=19" title="我的收藏">我的收藏</a></dd>
    <dd><a href="article.php?id=20" title="我的订单">我的订单</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=8' title="服务保证 ">服务保证 </a></dt>
    <dd><a href="article.php?id=21" title="退换货原则">退换货原则</a></dd>
    <dd><a href="article.php?id=22" title="售后服务保证 ">售后服务保证</a></dd>
    <dd><a href="article.php?id=23" title="产品质量保证 ">产品质量保证</a></dd>
  </dl>
<dl>
  <dt><a href='article_cat.php?id=9' title="联系我们 ">联系我们 </a></dt>
    <dd><a href="article.php?id=24" title="网站故障报告">网站故障报告</a></dd>
    <dd><a href="article.php?id=25" title="选机咨询 ">选机咨询</a></dd>
    <dd><a href="article.php?id=26" title="投诉与建议 ">投诉与建议</a></dd>
  </dl>
   </div>
  </div>
</div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="links clearfix">
        <a href="http://www.ecshop.com/" target="_blank" title="ECSHOP 网上商店管理系统"><img src="http://www.ecshop.com/images/logo/ecshop_logo.gif" alt="ECSHOP 网上商店管理系统" border="0" /></a>
                [<a href="http://www.maifou.net/" target="_blank" title="免费申请网店">免费申请网店</a>]
        [<a href="http://www.wdwd.com/" target="_blank" title="免费开独立网店">免费开独立网店</a>]
          </div>
 </div>
</div>
<div class="blank"></div>
<div id="bottomNav" class="box">
 <div class="box_1">
  <div class="bNavList clearfix">
   <div class="f_l">
              <a href="article.php?id=1" >免责条款</a>
                   -
                      <a href="article.php?id=2" >隐私保护</a>
                   -
                      <a href="article.php?id=3" >咨询热点</a>
                   -
                      <a href="article.php?id=4" >联系我们</a>
                   -
                      <a href="article.php?id=5" >公司简介</a>
                   -
                      <a href="wholesale.php" >批发方案</a>
                   -
                      <a href="myship.php" >配送方式</a>
                   -
                      <a href="user.php?act=register&type=agent" >业务经理注册</a>
                   -
                      <a href="user.php?act=register&type=distributor" >经销商注册</a>
                   </div>
   <div class="f_r">
   <a href="#top"><img src="themes/default/images/bnt_top.gif" /></a> <a href="index.php"><img src="themes/default/images/bnt_home.gif" /></a>
   </div>
  </div>
 </div>
</div>
<div class="blank"></div>
<div id="footer">
 <div class="text">
 &copy; 2005-2011 ECSHOP 版权所有，并保留所有权利。<br />
                                                                                     <br />
    554fcae493e564ee0dc75bdf2ebf94caquery_info|a:1:{s:4:"name";s:10:"query_info";}554fcae493e564ee0dc75bdf2ebf94ca<br />
  <a href="http://www.ecshop.com" target="_blank" style=" font-family:Verdana; font-size:11px;">Powered&nbsp;by&nbsp;<strong><span style="color: #3366FF">ECShop</span>&nbsp;<span style="color: #FF9966">v2.7.2</span></strong></a>&nbsp;<br />
        <div align="left"  id="rss"><a href="feed.php"><img src="themes/default/images/xml_rss2.gif" alt="rss" /></a></div>
 </div>
</div>
</body>
</html>
