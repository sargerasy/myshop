<?php 
$k = array (
  'name' => 'vote',
);
echo $this->_echash . $k['name'] . '|' . serialize($k) . $this->_echash;
?>