<!-- $Id: topic_edit.htm 16992 2010-01-19 08:45:49Z wangleisvn $ -->

<?php echo $this->fetch('pageheader.htm'); ?>
<?php echo $this->smarty_insert_scripts(array('files'=>'../js/utils.js,selectzone.js,colorselector_topic.js')); ?>
<script type="text/javascript" src="../js/calendar.php?lang=<?php echo $this->_var['cfg_lang']; ?>"></script>
<link href="../js/calendar/calendar.css" rel="stylesheet" type="text/css" />
<?php if ($this->_var['warning']): ?>
<ul style="padding:0; margin: 0; list-style-type:none; color: #CC0000;">
  <li style="border: 1px solid #CC0000; background: #FFFFCC; padding: 10px; margin-bottom: 5px;" ><?php echo $this->_var['warning']; ?></li>
</ul>
<?php endif; ?>
<!-- start goods form -->
<div class="tab-div">
  <!-- tab bar -->
  <div id="tabbar-div">
    <p> <span class="tab-front" id="general-tab"><?php echo $this->_var['lang']['tab_general']; ?></span> <span class="tab-back" id="goods-tab"><?php echo $this->_var['lang']['tab_goods']; ?></span> <span class="tab-back" id="desc-tab"><?php echo $this->_var['lang']['tab_desc']; ?></span><span class="tab-back" id="advanced-tab"><?php echo $this->_var['lang']['tab_advanced']; ?></span> </p>
  </div>
  <!-- tab body -->
  <div id="tabbody-div">
    <form action="topic.php" method="post" name="theForm" enctype="multipart/form-data">
      <table cellspacing="1"  id="general-table" cellpadding="3" width="100%">
        <tr>
          <td class="label"><?php echo $this->_var['lang']['topic_title']; ?></td>
          <td><input name="topic_name" type="text" value="<?php echo $this->_var['topic']['title']; ?>" size="40" /></td>
        </tr>
        <tr>
          <td class="label"><?php echo $this->_var['lang']['lable_topic_keywords']; ?></td>
          <td><textarea name="keywords" id="keywords" cols="40" rows="3"><?php echo $this->_var['topic']['keywords']; ?></textarea></td>
        </tr>
        <tr>
          <td class="label"><?php echo $this->_var['lang']['lable_topic_description']; ?></td>
          <td><textarea name="description" id="description" cols="40" rows="5"><?php echo $this->_var['topic']['description']; ?></textarea></td>
        </tr>
        <tr>
          <td class="label"><?php echo $this->_var['lang']['lable_topic_type']; ?></td>
          <td><select name="topic_type" id="topic_type" onchange="showMedia(this.value)">
       <option value='0'><?php echo $this->_var['lang']['top_img']; ?></option>
       <option value='1'><?php echo $this->_var['lang']['top_flash']; ?></option>
       <option value='2'><?php echo $this->_var['lang']['top_html']; ?></option>
       </select></td>
        </tr>
        <tbody id="content_01">
          <tr>
            <td  class="label">
              <a href="javascript:showNotice('title_upload');" title="<?php echo $this->_var['lang']['form_notice']; ?>">
              <img src="images/notice.gif" width="16" height="16" border="0" alt="<?php echo $this->_var['lang']['form_notice']; ?>"></a><?php echo $this->_var['lang']['lable_upload']; ?></td>
            <td>
              <input type='file' name='topic_img' id='topic_img' size='35' />
              <br /><span class="notice-span" <?php if ($this->_var['help_open']): ?>style="display:block" <?php else: ?> style="display:none" <?php endif; ?> id="title_upload"><?php echo $this->_var['width_height']; ?></span></td>
          </tr>
          <tr>
            <td class="label"><?php echo $this->_var['lang']['lable_from_web']; ?></td>
            <td><input type="text" name="url" id="url" value="" size="35" /></td>
          </tr>
        </tbody>
        
        <tbody id="edit_img">
          <tr>
            <td class="label">&nbsp;</td>
            <td><input type="text" name="img_url" id="img_url" value="<?php echo $this->_var['topic']['topic_img']; ?>" size="35" readonly="readonly"/></td>
          </tr>
        </tbody>

        <tbody id="content_23">
          <tr>
            <td class="label"><?php echo $this->_var['lang']['lable_content']; ?></td>
            <td><textarea name="htmls" id="htmls" cols="50" rows="7"><?php echo $this->_var['topic']['htmls']; ?></textarea></td>
          </tr>
        </tbody>
        
        <tr>
          <td  class="label"><a href="javascript:showNotice('title_pic_upload');" title="<?php echo $this->_var['lang']['form_notice']; ?>">
              <img src="images/notice.gif" width="16" height="16" border="0" alt="<?php echo $this->_var['lang']['form_notice']; ?>"></a><?php echo $this->_var['lang']['lable_title_upload']; ?></td>
          <td><input type='file' name='title_pic' id='title_pic' size='35' />
          <br /><span class="notice-span" <?php if ($this->_var['help_open']): ?>style="display:block" <?php else: ?> style="display:none" <?php endif; ?> id="title_pic_upload"><?php echo $this->_var['title_width_height']; ?></span></td>
        </tr>
        <tr>
          <td class="label"><?php echo $this->_var['lang']['lable_from_web']; ?></td>
          <td><input type="text" name="title_url" id="title_url" value="" size="35" /></td>
        </tr>

        <tbody id="edit_title_img">
          <tr>
            <td class="label">&nbsp;</td>
            <td><input type="text" name="title_img_url" id="title_img_url" value="<?php echo $this->_var['topic']['title_pic']; ?>" size="35" readonly="readonly"/></td>
          </tr>
        </tbody>

        <tr>
          <td class="label"><?php echo $this->_var['lang']['lable_base_style']; ?></td>
          <td><input type="text" name="base_style" id="base_style" value="<?php echo $this->_var['topic']['base_style']; ?>" size="7" maxlength="6" style="float:left;color:<?php echo $this->_var['goods_name_color']; ?>;" size="30"/><div style="background-color:#<?php echo $this->_var['topic']['base_style']; ?>;float:left;margin-left:2px;" id="font_color" onclick="ColorSelecter.Show(this);"><img src="images/color_selecter.gif" style="margin-top:-1px;" /></div></td>
        </tr>

        <tr>
          <td class="label"><?php echo $this->_var['lang']['cycle']; ?></td>
          <td><input name="start_time" type="text" id="start_time" size="12" value='<?php echo $this->_var['topic']['start_time']; ?>' readonly="readonly" />
            <input name="selbtn1" type="button" id="selbtn1" onclick="return showCalendar('start_time', '%Y-%m-%d', false, false, 'selbtn1');" value="<?php echo $this->_var['lang']['btn_select']; ?>" class="button"/>
            -
            <input name="end_time" type="text" id="end_time" size="12" value='<?php echo $this->_var['topic']['end_time']; ?>' readonly="readonly" />
            <input name="selbtn2" type="button" id="selbtn2" onclick="return showCalendar('end_time', '%Y-%m-%d', false, false, 'selbtn2');" value="<?php echo $this->_var['lang']['btn_select']; ?>" class="button"/></td>
        </tr>
      </table>
      <table width="90%" border="0"  align="center" cellpadding="0" cellspacing="0" id="goods-table" style="display:none;" >
        <tr>
          <td colspan="4" class="label" style="text-align:left"><?php echo $this->_var['lang']['topic_class']; ?>
            <select name="topic_class_list" id="topic_class_list" onchange="showTargetList()">
            </select>
            <input name="new_cat_name" type="text" id="new_cat_name" />
            <input name="create_class_btn" type="button" id="create_class_btn" value="<?php echo $this->_var['lang']['add']; ?>" class="button" onclick="addClass()" />
            <input name="delete_class_btn" type="button" id="delete_class_btn" value="<?php echo $this->_var['lang']['remove']; ?>" class="button" onclick="deleteClass()" />          </td>
        </tr>
        <tr>
          <td colspan="3"><img src="images/icon_search.gif" width="26" height="22" border="0" alt="SEARCH" />
            <select name="cat_id2">
              <option value="0"><?php echo $this->_var['lang']['all_category']; ?></option>
              <?php echo $this->_var['cat_list']; ?>
            </select>
            <select name="brand_id2">
              <option value="0"><?php echo $this->_var['lang']['all_brand']; ?></option>
              <?php echo $this->html_options(array('options'=>$this->_var['brand_list'])); ?>
            </select>
            <input type="text" name="keyword2"/>
            <input name="button" type="button" class="button" onclick="searchGoods('cat_id2', 'brand_id2', 'keyword2')" value="<?php echo $this->_var['lang']['button_search']; ?>" />          </td>
        </tr>
        <!-- 商品列表 -->
        <tr height="37">
          <th><?php echo $this->_var['lang']['all_goods']; ?></th>
          <th><?php echo $this->_var['lang']['handler']; ?></th>
          <th><?php echo $this->_var['lang']['selected_goods']; ?></th>
        </tr>
        <tr>
          <td width="42%"><select name="source_select" id="source_select" size="20" style="width:100%;height:300px;"  ondblclick="addItem(this)">
            </select>          </td>
          <td align="center"><p>
              <input name="button" type="button" class="button" onclick="addAllItem(document.getElementById('source_select'))" value="&gt;&gt;" />
            </p>
            <p>
              <input name="button" type="button" class="button" onclick="addItem(document.getElementById('source_select'))" value="&gt;" />
            </p>
            <p>
              <input name="button" type="button" class="button" onclick="removeItem(document.getElementById('target_select'))" value="&lt;" />
            </p>
            <p>
              <input name="button" type="button" class="button" value="&lt;&lt;" onclick="removeItem(document.getElementById('target_select'), true)" />
            </p></td>
          <td width="42%"><select name="target_select" id="target_select" size="20" style="width:100%;height:300px" multiple="multiple">
            </select>          </td>
        </tr>
      </table>
      <table width="90%" border="0"  align="center" cellpadding="0" cellspacing="0" id="desc-table" style="display:none;">
        <tr>
          <td><?php echo $this->_var['FCKeditor']; ?></td>
        </tr>
      </table>
      <table width="90%" border="0"  align="center" cellpadding="0" cellspacing="0" id="advanced-table" style="display:none;">
          <tr>
          <td class="label"><a href="javascript:showNotice('noticeTemplateFile');" title="<?php echo $this->_var['lang']['form_notice']; ?>"><img src="images/notice.gif" width="16" height="16" border="0" alt="<?php echo $this->_var['lang']['form_notice']; ?>"></a><?php echo $this->_var['lang']['template_file']; ?></td>
          <td ><input name="topic_template_file" type="text" id="topic_template_file" value="<?php echo $this->_var['topic']['template']; ?>" size="40" />
          <span class="notice-span" <?php if ($this->_var['help_open']): ?>style="display:block" <?php else: ?> style="display:none" <?php endif; ?> id="noticeTemplateFile"><?php echo $this->_var['lang']['notice_template_file']; ?></span></td>
        </tr>
        <tr>
          <td class="label"><a href="javascript:showNotice('noticeCss');" title="<?php echo $this->_var['lang']['form_notice']; ?>"><img src="images/notice.gif" width="16" height="16" border="0" alt="<?php echo $this->_var['lang']['form_notice']; ?>"></a><?php echo $this->_var['lang']['style_sheet']; ?></td>
          <td ><textarea name="topic_css" id="topic_css" cols="40" rows="5"><?php echo $this->_var['topic']['css']; ?></textarea>
            <span class="notice-span" <?php if ($this->_var['help_open']): ?>style="display:block" <?php else: ?> style="display:none" <?php endif; ?> id="noticeCss"><?php echo $this->_var['lang']['notice_css']; ?></span>
            <div> <a href="javascript:chanageSize(3,'topic_css');">[+]</a> <a href="javascript:chanageSize(-3,'topic_css');">[-]</a> </div></td>
        </tr>
      </table>
      <div class="button-div">
        <input  name="topic_data" type="hidden" id="topic_data" value='' />
        <input  name="act" type="hidden" id="act" value='<?php echo $this->_var['act']; ?>' />
        <input  name="topic_id" type="hidden" id="topic_id" value='<?php echo $this->_var['topic']['topic_id']; ?>' />
        <input type="submit"  name="Submit"       value="<?php echo $this->_var['lang']['button_submit']; ?>" class="button" onclick="return checkForm()"/>
        <input type="reset"   name="Reset"        value="<?php echo $this->_var['lang']['button_reset']; ?>" class="button"/>
      </div>
    </form>
  </div>
</div>
<?php echo $this->smarty_insert_scripts(array('files'=>'validator.js,tab.js')); ?>
<script type="Text/Javascript" language="JavaScript">
<!--
var data = '<?php echo $this->_var['topic']['data']; ?>';
var defaultClass = "<?php echo $this->_var['lang']['default_class']; ?>";

var myTopic = Object();
var status_code = "<?php echo $this->_var['topic']['topic_type']; ?>"; // 初始页面参数

onload = function()
{
  
  // 开始检查订单
  startCheckOrder();
  var classList = document.getElementById("topic_class_list");

  // 初始化表单项
  initialize_form(status_code);

  if (data == "")
  {
    
    classList.innerHTML = "";
    myTopic['default'] = new Array();
    var newOpt    = document.createElement("OPTION");
    newOpt.value  = -1;
    newOpt.text   = defaultClass;
    classList.options.add(newOpt);
    return;
  }
  var temp    = data.parseJSON();

  var counter = 0;
  for (var k in temp)
  {
    if(typeof(myTopic[k]) != "function")
    {
      myTopic[k] = temp[k];
      var newOpt    = document.createElement("OPTION");
      newOpt.value  = k == "default" ? -1 : counter;
      newOpt.text   = k == "default" ? defaultClass : k;
      classList.options.add(newOpt);
      counter++;
    }
  }
  showTargetList();
}

/**
 * 初始化表单项目
 */
function initialize_form(status_code)
{
  var nt = navigator_type();
  var display_yes = (nt == 'IE') ? 'block' : 'table-row-group';
  status_code = parseInt(status_code);
  status_code = status_code ? status_code : 0;
  document.getElementById('topic_type').options[status_code].selected = true;

  switch (status_code)
  {
    case 0 :
      document.getElementById('content_01').style.display = display_yes;
      document.getElementById('content_23').style.display = 'none';
			document.getElementById('title_upload').innerHTML = '<?php echo $this->_var['width_height']; ?>';
			document.getElementById('edit_img').style.display = display_yes;
    break;
		
    case 1 :
      document.getElementById('content_01').style.display = display_yes;
      document.getElementById('content_23').style.display = 'none';
			document.getElementById('title_upload').innerHTML = '<?php echo $this->_var['lang']['tips_upload_notice']; ?>';
			document.getElementById('edit_img').style.display = display_yes;
    break;
		
    case 2 :
      document.getElementById('content_01').style.display = 'none';
      document.getElementById('content_23').style.display = display_yes;
			document.getElementById('edit_img').style.display = 'none';
    break;
  }

	<?php if ($this->_var['isadd'] == 'isadd'): ?>
	document.getElementById('edit_img').style.display = 'none';
	document.getElementById('edit_title_img').style.display = 'none';
	<?php endif; ?>

  return true;
}

/**
 * 类型表单项切换
 */
function showMedia(code)
{
  var obj = document.getElementById('topic_type');

  initialize_form(code);
}

function checkForm()
{
  var validator = new Validator('theForm');
  validator.required('topic_name', topic_name_empty);
  validator.required('start_time', start_time_empty);
  validator.required('end_time', end_time_empty);
  validator.islt('start_time', 'end_time', start_lt_end);

  document.getElementById("topic_data").value = myTopic.toJSONString();

  return validator.passed();
}

function chanageSize(num, id)
{
  var obj = document.getElementById(id);
  if (obj.tagName == "TEXTAREA")
  {
    var tmp = parseInt(obj.rows);
    tmp += num;
    if (tmp <= 0) return;
    obj.rows = tmp;
  }
}

function searchGoods(catId, brandId, keyword)
{
  var elements = document.forms['theForm'].elements;
  var filters = new Object;
  filters.cat_id = elements[catId].value;
  filters.brand_id = elements[brandId].value;
  filters.keyword = Utils.trim(elements[keyword].value);
  Ajax.call("topic.php?act=get_goods_list", filters, function(result)
  {
    clearOptions("source_select");
    var obj = document.getElementById("source_select");
    for (var i=0; i < result.content.length; i++)
    {
      var opt   = document.createElement("OPTION");
      opt.value = result.content[i].value;
      opt.text  = result.content[i].text;
      opt.id    = result.content[i].data;
      obj.options.add(opt);
    }
  }, "GET", "JSON");
}

function clearOptions(id)
{
  var obj = document.getElementById(id);
  while(obj.options.length>0)
  {
    obj.remove(0);
  }
}

function addAllItem(sender)
{
  if(sender.options.length == 0) return false;
  for (var i = 0; i < sender.options.length; i++)
  {
    var opt = sender.options[i];
    addItem(null, opt.value, opt.text);
  }
}

function addItem(sender, value, text)
{
  var target_select = document.getElementById("target_select");
  var sortList = document.getElementById("topic_class_list");
  var newOpt   = document.createElement("OPTION");
  if (sender != null)
  {
    if(sender.options.length == 0) return false;
    var option = sender.options[sender.selectedIndex];
    newOpt.value = option.value;
    newOpt.text  = option.text;
  }
  else
  {
    newOpt.value = value;
    newOpt.text  = text;
  }
  if (targetItemExist(newOpt)) return false;
  if (target_select.length>=50)
  {
    alert(item_upper_limit);
  }
  target_select.options.add(newOpt);
  var key = sortList.options[sortList.selectedIndex].value == "-1" ? "default" : sortList.options[sortList.selectedIndex].text;
  
  if(!myTopic[key])
  {
    myTopic[key] = new Array();
  }
  myTopic[key].push(newOpt.text + "|" + newOpt.value);
}

// 商品是否存在
function targetItemExist(opt)
{
  var options = document.getElementById("target_select").options;
  for ( var i = 0; i < options.length; i++)
  {
    if(options[i].text == opt.text && options[i].value == opt.value) 
    {
      return true;
    }
  }
  return false;
}

function addClass()
{
  var obj = document.getElementById("topic_class_list");
  var newClassName = document.getElementById("new_cat_name");
  var regExp = /^[a-zA-Z0-9]+$/;
  if (newClassName.value == ""){
    alert(sort_name_empty);
    return;
  }
  for(var i=0;i < obj.options.length; i++)
  {
    if(obj.options[i].text == newClassName.value)
    {
      alert(sort_name_exist);
      newClassName.focus(); 
      return;
    }
  }
  var className = document.getElementById("new_cat_name").value;
  document.getElementById("new_cat_name").value = "";
  var newOpt    = document.createElement("OPTION");
  newOpt.value  = obj.options.length;
  newOpt.text   = className;
  obj.options.add(newOpt);
  newOpt.selected = true;
  if ( obj.options[0].value == "-1")
  {
    if (myTopic["default"].length > 0)
      alert(move_item_confirm.replace("className",className));
    myTopic[className] = myTopic["default"];
    delete myTopic["default"];
    obj.remove(0);
  }
  else
  {
    myTopic[className] = new Array();
    clearOptions("target_select");
  }
}

function deleteClass()
{
  var classList = document.getElementById("topic_class_list");
  if (classList.value != "-1")
  {
    delete myTopic[classList.options[classList.selectedIndex].text];
    classList.remove(classList.selectedIndex);
    clearOptions("target_select");
  }
  if (classList.options.length < 1)
  {
    var newOpt    = document.createElement("OPTION");
    newOpt.value  = "-1";
    newOpt.text   = defaultClass;
    classList.options.add(newOpt);
    myTopic["default"] = new Array();
  }
}

function showTargetList()
{
  clearOptions("target_select");
  var obj = document.getElementById("topic_class_list");
  var index = obj.options[obj.selectedIndex].text;
  if (index == defaultClass)
  {
    index = "default";
  }
  var options = myTopic[index];
  
  for ( var i = 0; i < options.length; i++)
  {
    var newOpt    = document.createElement("OPTION");
    var arr = options[i].split('|');
    newOpt.value  = arr[1];
    newOpt.text   = arr[0];
    document.getElementById("target_select").options.add(newOpt);
  }
}

function removeItem(sender,isAll)
{
  var classList = document.getElementById("topic_class_list");
  var key = 'default';
  if (classList.value != "-1")
  {
    key = classList.options[classList.selectedIndex].text;
  }
  var arr = myTopic[key];
  if (!isAll)
  {
    var goodsName = sender.options[sender.selectedIndex].text;
    for (var j = 0; j < arr.length; j++)
    {
      if (arr[j].indexOf(goodsName) >= 0)
      {
          myTopic[key].splice(j,1);
      }
    }

    for (var i = 0; i < sender.options.length;)
    {
      if (sender.options[i].selected) {
        sender.remove(i);
        myTopic[key].splice(i, 0);
      }
      else
      {
        i++;
      }
    }
  }
  else
  {
    myTopic[key] = new Array();
    sender.innerHTML = "";
  }
}

/**
 * 判断当前浏览器类型
 */
function navigator_type()
{
  var type_name = '';

  if (navigator.userAgent.indexOf('MSIE') != -1)
  {
    type_name = 'IE'; // IE
  }
  else if(navigator.userAgent.indexOf('Firefox') != -1)
  {
    type_name = 'FF'; // FF
  }
  else if(navigator.userAgent.indexOf('Opera') != -1)
  {
    type_name = 'Opera'; // Opera
  }
  else if(navigator.userAgent.indexOf('Safari') != -1)
  {
    type_name = 'Safari'; // Safari
  }
  else if(navigator.userAgent.indexOf('Chrome') != -1)
  {
    type_name = 'Chrome'; // Chrome
  }

  return type_name;
}

//-->
</script>
<?php echo $this->fetch('pagefooter.htm'); ?>
