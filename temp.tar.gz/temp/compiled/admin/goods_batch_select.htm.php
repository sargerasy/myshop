<!-- $Id: goods_batch_select.htm 14216 2008-03-10 02:27:21Z testyang $ -->
<?php echo $this->fetch('pageheader.htm'); ?>
<div class="main-div">
  <form name="theForm" method="post" action="goods_batch.php?act=edit" onsubmit="return getGoodsIDs()">
  <table cellspacing="1" cellpadding="3" width="100%">
  <tr>
    <td class="narrow-label"><?php echo $this->_var['lang']['select_method']; ?></td>
    <td>
      <label><input name="select_method" id="sm_cat" type="radio" value="cat" checked onclick="toggleSelectMethod(this.value)"><?php echo $this->_var['lang']['by_cat']; ?></label>
      <label><input name="select_method" id="sm_sn" type="radio" value="sn" onclick="toggleSelectMethod(this.value)"><?php echo $this->_var['lang']['by_sn']; ?></label>    </td>
  </tr>
  <tr id="cat_1">
    <td class="narrow-label" id="cat_2"><?php echo $this->_var['lang']['select_cat']; ?></td>
    <td id="cat_3">&nbsp;<select name="cat" id="cat" onchange="getGoods()">
      <option value="0" selected><?php echo $this->_var['lang']['select_please']; ?></option><?php echo $this->_var['cat_list']; ?>
    </select></td>
  </tr>
  <tr id="cat_7">
    <td class="narrow-label" id="cat_8"><?php echo $this->_var['lang']['select_brand']; ?></td>
    <td id="cat_9">&nbsp;<select name="brand" id="brand" onchange="getGoods()">
      <option value="0" selected><?php echo $this->_var['lang']['select_please']; ?></option>
      <?php echo $this->html_options(array('options'=>$this->_var['brand_list'])); ?>
    </select></td>
  </tr>
  <tr id="cat_4">
    <td class="narrow-label" id="cat_5"><?php echo $this->_var['lang']['goods_list']; ?></td>
    <td valign="middle" id="cat_6">
      <table  border="0" cellspacing="1" cellpadding="3">
      <tr>
        <td><?php echo $this->_var['lang']['src_list']; ?></td>
        <td align="center" valign="middle">&nbsp;</td>
        <td><?php echo $this->_var['lang']['dest_list']; ?></td>
      </tr>
      <tr>
        <td width="45%">
          <select name="srcList" size="10" multiple id="srcList" style="width: 100%" ondblclick="addGoods()"></select>
        </td>
        <td align="center" valign="middle"><input name="add" type="button" class="button" id="add" value="&gt;&gt;" onclick="addGoods()" /><br />
          <input name="del" class="button" type="button" id="del" value="&lt;&lt;" onclick="delGoods()" /></td>
        <td width="45%">
          <select name="destList" size="10" multiple id="destList" style="width: 100%" ondblclick="delGoods()"></select>
        </td>
      </tr>
      </table>
    </td>
  </tr>
  <tr style="display:none" id="sn_1">
    <td class="narrow-label" style="display:none" id="sn_2"><?php echo $this->_var['lang']['input_sn']; ?></td>
    <td style="display:none" id="sn_3"><textarea name="sn_list" rows="10" cols="40" id="sn_list"></textarea></td>
  </tr>
  <tr>
    <td class="narrow-label"><?php echo $this->_var['lang']['edit_method']; ?></td>
    <td>
      <label><input name="edit_method" type="radio" value="each" checked>
      <?php echo $this->_var['lang']['edit_each']; ?></label>
      <label><input type="radio" name="edit_method" value="all"><?php echo $this->_var['lang']['edit_all']; ?></label>    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" value="<?php echo $this->_var['lang']['go_edit']; ?>" class="button" />
      <input type="hidden" name="goods_ids" value="" /></td>
  </tr>
  </table>
  </form>

</div>


<script language="JavaScript">
  var ele = document.forms['theForm'].elements;

  onload = function()
  {
    // 开始检查订单
      startCheckOrder();
  }

  /**
   * 切换选择商品方式：
   * @param: method 当前方式 cat sn
   */
  function toggleSelectMethod(method)
  {
    if (method == 'cat')
    {
        var catDisplay = '';
        var snDisplay = 'none';
    }
    else
    {
        var catDisplay = 'none';
        var snDisplay = '';
    }

    for (var i = 1; i <= 9; i++)
    {
       document.getElementById('cat_' + i).style.display = catDisplay;
    }
    for (var i = 1; i <= 3; i++)
    {
       document.getElementById('sn_' + i).style.display = snDisplay;
    }
  }

  /**
   * 取得商品
   */
  function getGoods()
  {
      var catId   = ele['cat'].value;
      var brandId = ele['brand'].value;
      if (catId > 0 || brandId > 0)
      {
          Ajax.call('goods_batch.php?is_ajax=1&act=get_goods', "cat_id="+catId+"&brand_id="+brandId, getGoodsResponse, "GET", "JSON");
      }
      else
      {
          ele['srcList'].options.length = 0;
      }
  }

  function getGoodsResponse(result)
  {
    if (result.error == 0)
    {
      ele['srcList'].options.length = 0;

      for (var i = 0; i < result.content.length; i++)
      {
        var opt = document.createElement('OPTION');
        opt.value = result.content[i].goods_id;
        opt.text = result.content[i].goods_name;
        ele['srcList'].options.add(opt);
      }
    }
  }

  /**
   * 添加商品
   */
  function addGoods()
  {
      var src = document.getElementById('srcList');
      var dest = document.getElementById('destList');

      for (var i = 0; i < src.options.length; i++)
      {
          if (src.options[i].selected)
          {
              var exist = false;
              for (var j = 0; j < dest.options.length; j++)
              {
                  if (dest.options[j].value == src.options[i].value)
                  {
                      exist = true;
                      break;
                  }
              }
              if (!exist)
              {
                  var opt = document.createElement('OPTION');
                  opt.value = src.options[i].value;
                  opt.text = src.options[i].text;
                  dest.options.add(opt);
              }
          }
      }
  }

  /**
   * 删除商品
   */
  function delGoods()
  {
      var dest = document.getElementById('destList');

      for (var i = dest.options.length - 1; i >= 0 ; i--)
      {
          if (dest.options[i].selected)
          {
              dest.options[i] = null;
          }
      }
  }

  /**
   * 取得选择的商品id，赋值给隐藏变量。同时检查是否选择或输入了商品
   */
  function getGoodsIDs()
  {
      if (document.getElementById('sm_cat').checked)
      {
          var idArr = new Array();
          var dest = document.getElementById('destList');
          for (var i = 0; i < dest.options.length; i++)
          {
              idArr.push(dest.options[i].value);
          }
          if (idArr.length <= 0)
          {
              alert(please_select_goods);
              return false;
          }
          else
          {
              document.forms['theForm'].elements['goods_ids'].value = idArr.join(',');
              return true;
          }
      }
      else
      {
          if (document.forms['theForm'].elements['sn_list'].value == '')
          {
              alert(please_input_sn);
              return false;
          }
          else
          {
              return true;
          }
      }
  }
</script>

<?php echo $this->fetch('pagefooter.htm'); ?>