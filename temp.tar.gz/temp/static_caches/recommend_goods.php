<?php
$data = array (
  'best' => 
  array (
    0 => 
    array (
      'goods_id' => '24',
      'sort_order' => '100',
    ),
    1 => 
    array (
      'goods_id' => '9',
      'sort_order' => '100',
    ),
    2 => 
    array (
      'goods_id' => '1',
      'sort_order' => '100',
    ),
    3 => 
    array (
      'goods_id' => '8',
      'sort_order' => '100',
    ),
    4 => 
    array (
      'goods_id' => '17',
      'sort_order' => '100',
    ),
    5 => 
    array (
      'goods_id' => '19',
      'sort_order' => '100',
    ),
    6 => 
    array (
      'goods_id' => '20',
      'sort_order' => '100',
    ),
    7 => 
    array (
      'goods_id' => '22',
      'sort_order' => '100',
    ),
    8 => 
    array (
      'goods_id' => '23',
      'sort_order' => '100',
    ),
    9 => 
    array (
      'goods_id' => '27',
      'sort_order' => '100',
    ),
    10 => 
    array (
      'goods_id' => '30',
      'sort_order' => '100',
    ),
    11 => 
    array (
      'goods_id' => '25',
      'sort_order' => '100',
    ),
    12 => 
    array (
      'goods_id' => '29',
      'sort_order' => '100',
    ),
    13 => 
    array (
      'goods_id' => '5',
      'sort_order' => '100',
    ),
  ),
  'new' => 
  array (
    0 => 
    array (
      'goods_id' => '24',
      'sort_order' => '100',
    ),
    1 => 
    array (
      'goods_id' => '32',
      'sort_order' => '100',
    ),
    2 => 
    array (
      'goods_id' => '9',
      'sort_order' => '100',
    ),
    3 => 
    array (
      'goods_id' => '1',
      'sort_order' => '100',
    ),
    4 => 
    array (
      'goods_id' => '8',
      'sort_order' => '100',
    ),
    5 => 
    array (
      'goods_id' => '19',
      'sort_order' => '100',
    ),
    6 => 
    array (
      'goods_id' => '20',
      'sort_order' => '100',
    ),
    7 => 
    array (
      'goods_id' => '22',
      'sort_order' => '100',
    ),
    8 => 
    array (
      'goods_id' => '23',
      'sort_order' => '100',
    ),
    9 => 
    array (
      'goods_id' => '12',
      'sort_order' => '100',
    ),
    10 => 
    array (
      'goods_id' => '27',
      'sort_order' => '100',
    ),
    11 => 
    array (
      'goods_id' => '5',
      'sort_order' => '100',
    ),
  ),
  'hot' => 
  array (
    0 => 
    array (
      'goods_id' => '24',
      'sort_order' => '100',
    ),
    1 => 
    array (
      'goods_id' => '32',
      'sort_order' => '100',
    ),
    2 => 
    array (
      'goods_id' => '9',
      'sort_order' => '100',
    ),
    3 => 
    array (
      'goods_id' => '1',
      'sort_order' => '100',
    ),
    4 => 
    array (
      'goods_id' => '8',
      'sort_order' => '100',
    ),
    5 => 
    array (
      'goods_id' => '13',
      'sort_order' => '100',
    ),
    6 => 
    array (
      'goods_id' => '14',
      'sort_order' => '100',
    ),
    7 => 
    array (
      'goods_id' => '17',
      'sort_order' => '100',
    ),
    8 => 
    array (
      'goods_id' => '19',
      'sort_order' => '100',
    ),
    9 => 
    array (
      'goods_id' => '20',
      'sort_order' => '100',
    ),
    10 => 
    array (
      'goods_id' => '10',
      'sort_order' => '100',
    ),
    11 => 
    array (
      'goods_id' => '27',
      'sort_order' => '100',
    ),
    12 => 
    array (
      'goods_id' => '30',
      'sort_order' => '100',
    ),
    13 => 
    array (
      'goods_id' => '25',
      'sort_order' => '100',
    ),
    14 => 
    array (
      'goods_id' => '29',
      'sort_order' => '100',
    ),
    15 => 
    array (
      'goods_id' => '28',
      'sort_order' => '100',
    ),
    16 => 
    array (
      'goods_id' => '26',
      'sort_order' => '100',
    ),
  ),
  'brand' => 
  array (
    24 => '联想',
    32 => '诺基亚',
    9 => '诺基亚',
    1 => 'LG',
    8 => '飞利浦',
    13 => '诺基亚',
    14 => '诺基亚',
    17 => '夏新',
    19 => '三星',
    20 => '三星',
    22 => '多普达',
    23 => '诺基亚',
    12 => '摩托罗拉',
    10 => '索爱',
    5 => '索爱',
  ),
);
?>